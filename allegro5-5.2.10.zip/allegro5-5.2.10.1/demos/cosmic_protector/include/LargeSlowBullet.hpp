#ifndef LARGESLOWBULLET_HPP
#define LARGESLOWBULLET_HPP

class LargeSlowBullet : public LargeBullet
{
public:
   LargeSlowBullet(float x, float y, float angle, Entity *shooter);
};

#endif // LARGESLOWBULLET_HPP

