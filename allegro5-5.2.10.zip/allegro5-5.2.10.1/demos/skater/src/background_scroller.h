#ifndef		__DEMO_BACK_SCROLLER__
#define		__DEMO_BACK_SCROLLER__

#include <allegro5/allegro.h>

void init_background(void);
void update_background(void);
void draw_background(void);

#endif				/* __DEMO_BACK_SCROLLER__ */
