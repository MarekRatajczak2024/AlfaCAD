#ifndef __al_included_allegro5_aintern_xglx_h
#define __al_included_allegro5_aintern_xglx_h

#include "allegro5/internal/aintern_x.h"

void _al_xglx_config_select_visual(ALLEGRO_DISPLAY_XGLX *glx);
bool _al_xglx_config_create_context(ALLEGRO_DISPLAY_XGLX *glx);

#endif
