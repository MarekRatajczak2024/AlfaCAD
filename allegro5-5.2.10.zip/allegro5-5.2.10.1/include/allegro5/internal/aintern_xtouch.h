#ifndef __al_included_allegro5_aintern_xtouch_h
#define __al_included_allegro5_aintern_xtouch_h

#include "allegro5/internal/aintern_touch_input.h"

void _al_x_handle_touch_event(ALLEGRO_SYSTEM_XGLX *s, ALLEGRO_DISPLAY_XGLX *d, XEvent *e);

#endif
