
 This is FreeType source bundled with Glyph Keeper library.

 I (Kirill Kryukov) made a few changes for better integration with
 Glyph Keeper:


 1. All sources are placed in a single directory "src". Removed all makefiles,
    jamfiles, and other unnecessary things.


 2. "include\freetype\config\ftoption.h":
    Added this to compile it as DLL on Windows:

#ifdef WIN32
#define  FT_EXPORT(x)       __declspec( dllexport ) x
#define  FT_EXPORT_DEF(x)   x
#endif
    

 3. "include\freetype\config\ftstdlib.h":
    Replaced this:

#define ft_scalloc   calloc
#define ft_sfree     free
#define ft_smalloc   malloc
#define ft_srealloc  realloc

    With this:

#ifndef GK_NO_LEGACY
#define GK_NO_LEGACY
#endif
#include "../../../../include/glyph.h"
#include "../../../../src/glyph_memory.h"

#define ft_scalloc   _gk_for_ft_calloc
#define ft_sfree     _gk_for_ft_free
#define ft_smalloc   _gk_for_ft_malloc
#define ft_srealloc  _gk_for_ft_realloc

    to enable memory debugging through Glyph Keeper API.
