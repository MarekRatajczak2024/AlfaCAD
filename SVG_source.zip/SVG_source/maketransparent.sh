cd transparent_64_www
for i in *; do rsvg-convert -w 64 -h 64 $i -o `echo $i | sed -e 's/svg$/png/'`; done;
mv *.png ../PNGWEB
cd ..
cd transparent_96_www
for i in *; do rsvg-convert -w 96 -h 96 $i -o `echo $i | sed -e 's/svg$/png/'`; done;
mv *.png ../PNGWEB
cd ..
cd transparent_128_www
for i in *; do rsvg-convert -w 128 -h 128 $i -o `echo $i | sed -e 's/svg$/png/'`; done;
mv *.png ../PNGWEB
cd ..
cd transparent_256_www
for i in *; do rsvg-convert -w 256 -h 256 $i -o `echo $i | sed -e 's/svg$/png/'`; done;
mv *.png ../PNGWEB
cd ..
