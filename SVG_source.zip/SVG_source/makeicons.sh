cd menu
for i in *; do rsvg-convert -w 32 -h 32 -b lightgrey $i -o `echo $i | sed -e 's/svg$/png/'`; done
mv *.png ../PNG32
cd ..
cd dialog_d12
for i in *; do rsvg-convert -w 12 -h 12 --background-color=#aaaaaa $i -o `echo $i | sed -e 's/svg$/png/'`; done;
mv *.png ../PNG32
cd ..
cd dialog_d24
for i in *; do rsvg-convert -w 24 -h 24 --background-color=#aaaaaa $i -o `echo $i | sed -e 's/svg$/png/'`; done;
mv *.png ../PNG32
cd ..
cd dialog_d32
for i in *; do rsvg-convert -w 32 -h 32 --background-color=#aaaaaa $i -o `echo $i | sed -e 's/svg$/png/'`; done;
mv *.png ../PNG32
cd ..
cd dialog_d48
for i in *; do rsvg-convert -w 48 -h 48 --background-color=#aaaaaa $i -o `echo $i | sed -e 's/svg$/png/'`; done;
mv *.png ../PNG32
cd ..
cd dialog_d64
for i in *; do rsvg-convert -w 64 -h 64 --background-color=#aaaaaa $i -o `echo $i | sed -e 's/svg$/png/'`; done;
mv *.png ../PNG32
cd ..
cd dialog_d128
for i in *; do rsvg-convert -w 128 -h 128 --background-color=#aaaaaa $i -o `echo $i | sed -e 's/svg$/png/'`; done;
mv *.png ../PNG32
cd ..
cd dialog_db32
for i in *; do rsvg-convert -w 32 -h 32 --background-color=#c3cfff $i -o `echo $i | sed -e 's/svg$/png/'`; done;
mv *.png ../PNG32
cd ..
cd dialog_db48
for i in *; do rsvg-convert -w 48 -h 48 --background-color=#c3cfff $i -o `echo $i | sed -e 's/svg$/png/'`; done;
mv *.png ../PNG32
cd ..
cd dialog_db64
for i in *; do rsvg-convert -w 64 -h 64 --background-color=#c3cfff $i -o `echo $i | sed -e 's/svg$/png/'`; done;
mv *.png ../PNG32
cd ..
cd transparent_32
for i in *; do rsvg-convert -w 32 -h 32 $i -o `echo $i | sed -e 's/svg$/png/'`; done;
mv *.png ../PNG32
cd ..
cd transparent_48
for i in *; do rsvg-convert -w 48 -h 48 $i -o `echo $i | sed -e 's/svg$/png/'`; done;
mv *.png ../PNG32
cd ..
cd transparent_64
for i in *; do rsvg-convert -w 64 -h 64 $i -o `echo $i | sed -e 's/svg$/png/'`; done;
mv *.png ../PNG32
cd ..
cd transparent_96
for i in *; do rsvg-convert -w 96 -h 96 $i -o `echo $i | sed -e 's/svg$/png/'`; done;
mv *.png ../PNG32
cd ..
cd transparent_128x64
for i in *; do rsvg-convert -w 128 -h 64 $i -o `echo $i | sed -e 's/svg$/png/'`; done;
mv *.png ../PNG32
cd ..
cd transparent_1024
for i in *; do rsvg-convert -w 1024 -h 1024 $i -o `echo $i | sed -e 's/svg$/png/'`; done;
mv *.png ../PNG1024
cd ..
