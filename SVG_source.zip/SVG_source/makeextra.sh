cd extra
for i in *; do rsvg-convert -w 32 -h 32 -b lightgrey $i -o `echo $i | sed -e 's/svg$/png/'`; done
mv *.png ../PNG32
cd ..
