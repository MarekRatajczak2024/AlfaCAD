cd transparent_4x16
for i in *; do rsvg-convert -w 4 -h 16 $i -o `echo $i | sed -e 's/svg$/png/'`; done
mv *.png ../CURSORS
cd ..
cd transparent_6x24
for i in *; do rsvg-convert -w 6 -h 24 $i -o `echo $i | sed -e 's/svg$/png/'`; done
mv *.png ../CURSORS
cd ..
cd transparent_8x32
for i in *; do rsvg-convert -w 8 -h 32 $i -o `echo $i | sed -e 's/svg$/png/'`; done
mv *.png ../CURSORS
cd ..
cd transparent_12x48
for i in *; do rsvg-convert -w 12 -h 48 $i -o `echo $i | sed -e 's/svg$/png/'`; done
mv *.png ../CURSORS
cd ..
cd transparent_16x64
for i in *; do rsvg-convert -w 16 -h 64 $i -o `echo $i | sed -e 's/svg$/png/'`; done
mv *.png ../CURSORS
cd ..
cd transparent_24x96
for i in *; do rsvg-convert -w 24 -h 96 $i -o `echo $i | sed -e 's/svg$/png/'`; done
mv *.png ../CURSORS
cd ..
cd transparent_32x128
for i in *; do rsvg-convert -w 32 -h 128 $i -o `echo $i | sed -e 's/svg$/png/'`; done
mv *.png ../CURSORS
cd ..
