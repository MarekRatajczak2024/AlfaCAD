cd transparent_12x16
for i in *; do rsvg-convert -w 12 -h 16 $i -o `echo $i | sed -e 's/svg$/png/'`; done
mv *.png ../CURSORS
cd ..
cd transparent_18x24
for i in *; do rsvg-convert -w 18 -h 24 $i -o `echo $i | sed -e 's/svg$/png/'`; done
mv *.png ../CURSORS
cd ..
cd transparent_24x32
for i in *; do rsvg-convert -w 24 -h 32 $i -o `echo $i | sed -e 's/svg$/png/'`; done
mv *.png ../CURSORS
cd ..
cd transparent_36x48
for i in *; do rsvg-convert -w 36 -h 48 $i -o `echo $i | sed -e 's/svg$/png/'`; done
mv *.png ../CURSORS
cd ..
cd transparent_48x64
for i in *; do rsvg-convert -w 48 -h 64 $i -o `echo $i | sed -e 's/svg$/png/'`; done
mv *.png ../CURSORS
cd ..
cd transparent_72x96
for i in *; do rsvg-convert -w 72 -h 96 $i -o `echo $i | sed -e 's/svg$/png/'`; done
mv *.png ../CURSORS
cd ..
cd transparent_96x128
for i in *; do rsvg-convert -w 96 -h 128 $i -o `echo $i | sed -e 's/svg$/png/'`; done
mv *.png ../CURSORS
cd ..
