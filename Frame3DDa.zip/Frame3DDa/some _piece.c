//
// Created by marek on 5/18/26.
//
/*
 * WRITE_INTERNAL_FORCES -
 * calculate frame element internal forces, Nx, Vy, Vz, Tx, My, Mz
 * calculate frame element local displacements, Rx, Dx, Dy, Dz
 * write internal forces and local displacements to an output data file
 * 4jan10, 7mar11, 21jan14
 */
void write_internal_forces_older (
        char OUT_file[],
        FILE *fp, char infcpath[], int lc, int nL, char title[], float dx,
        vec3 *xyz,
        double **Q, double **Qt, int nN, int nE, double *L, int *J1, int *J2, float *Rj,    //Rj comes here to include nodes radii so there is an extra parameter in main.c where the function is called  MAREK
        float *Ax,float *Asy,float *Asz,float *Jx,float *Iy,float *Iz,
        float *E, float *G, float *p,
        float *d, float gX, float gY, float gZ,
        int nU, float **U, int nW, float **W, int nP, float **P,
        double *D, int shear, double error,
        int *n1y, int *n1z, int *n2y, int *n2z,
        int *abscissas_n,
        double **abscissas
){
    double	t1, t2, t3, t4, t5, t6, t7, t8, t9, /* coord transformation */
    u1, u2, u3, u4, u5, u6, u7, u8, u9, u10, u11, u12; /* displ. */

    double	xx1,xx2, wx1,wx2,	/* trapz load data, local x dir */
    xy1,xy2, wy1,wy2,	/* trapz load data, local y dir */
    xz1,xz2, wz1,wz2;	/* trapz load data, local z dir */

    double	wx=0, wy=0, wz=0, // distributed loads in local coords at x[i]
    wx_=0,wy_=0,wz_=0,// distributed loads in local coords at x[i-1]
    wxg=0,wyg=0,wzg=0,// gravity loads in local x, y, z coord's
    tx=0.0, tx_=0.0;  // distributed torque about local x coord

    double	xp;		/* location of internal point loads	*/

    double	*x, dx_, dxnx,	/* distance along frame element		*/
    *Nx,		/* axial force within frame el.		*/
    *Vy, *Vz,	/* shear forces within frame el.	*/
    *Tx,		/* torsional moment within frame el.	*/
    *My, *Mz, 	/* bending moments within frame el.	*/
    *Sy, *Sz,	/* transverse slopes of frame el.	*/
    *Dx, *Dy, *Dz,	/* frame el. displ. in local x,y,z, dir's */
    *Rx;		/* twist rotation about the local x-axis */

    double  *Mzt; /* bending moments thermal in z axis within frame el.	*/
    double  *Myt; /* bending moments thermal in y axis within frame el.	*/
    double  *Dyt; /* frame el. displ. thermal in y direction in local x,y,z, dir's */
    double  *Dzt; /* frame el. displ. thermal in z direction in local x,y,z, dir's */

    double	maxNx, maxVy, maxVz, 	/*  maximum internal forces	*/
    maxTx, maxMy, maxMz,	/*  maximum internal moments	*/
    maxDx, maxDy, maxDz,	/*  maximum element displacements */
    maxRx, maxSy, maxSz;	/*  maximum element rotations	*/

    //double maxMzt;	/*  thermal moments associated with maximum internal moments*/

    double	minNx, minVy, minVz, 	/*  minimum internal forces	*/
    minTx, minMy, minMz,	/*  minimum internal moments	*/
    minDx, minDy, minDz,	/*  minimum element displacements */
    minRx, minSy, minSz;	/*  minimum element rotations	*/

    //double minMzt;	/*  thermal moments associated with maximum internal moments*/

    int	n, m,		/* frame element number			*/
    cU=0, cW=0, cP=0, /* counters for U, W, and P loads	*/
    i, nx,		/* number of sections alont x axis	*/
    n1,n2,i1,i2;	/* starting and stopping node no's	*/

    char	fnif[FILENMAX];/* file name    for internal force data	*/
    char	CSV_file[FILENMAX];
    char	errMsg[MAXL];
    char	wa[4];          /* indicate 'write' or 'append' to file */
    FILE	*fpif,		/* file pointer for internal force data */
    *fpcsv;         /* file pointer to .CSV output data file */
    time_t  now;		/* modern time variable type		*/

    if (dx == -1.0)	return;	// skip calculation of internal forces and displ

    (void) time(&now);


    CSV_filename( CSV_file, wa, OUT_file, lc );

    if (lc <= 1)
    {    // open CSV file for writing
        if ((fpcsv = fopen(CSV_file, "w")) == NULL)  //always created as new output file
        {
            sprintf(errMsg, "\n  error: cannot open CSV output data file: %s \n", CSV_file);
            errorMsg(errMsg);
            exit(17);
        }
    }
    else { //open CSV file to append
        if ((fpcsv = fopen(CSV_file, "a")) == NULL) {
            sprintf(errMsg, "\n  error: cannot open CSV output data file: %s \n", CSV_file);
            errorMsg(errMsg);
            exit(17);
        }
    }

    /* file name for internal force data for load case "lc" */
    sprintf(fnif,"%s%02d",infcpath,lc);

    /* open the interior force data file */
    if ((fpif = fopen (fnif, "w")) == NULL) {
        sprintf (errMsg,"\n  error: cannot open interior force data file: %s \n",fnif);
        errorMsg(errMsg);
        exit(19);
    }

    fprintf(fpif,"# FRAME3DD ANALYSIS RESULTS  http://frame3dd.sf.net/");
    fprintf(fpif," VERSION %s \n", VERSION);
    fprintf(fpif,"# %s\n", title );
    fprintf(fpif,"# %s\n", fnif);
    fprintf(fpif,"# %s", ctime(&now) );
    fprintf(fpif,"# L O A D  C A S E   %d  of   %d \n", lc, nL );
    fprintf(fpif,"# F R A M E   E L E M E N T   I N T E R N A L   F O R C E S (local)\n");
    fprintf(fpif,"# F R A M E   E L E M E N T   T R A N S V E R S E   D I S P L A C E M E N T S (local)\n\n");

    // write header information for each frame element to txt output data file
    fprintf(fp,"\nP E A K   F R A M E   E L E M E N T   I N T E R N A L   F O R C E S");
    fprintf(fp,"(local)\", \n");
    fprintf(fp,"  Elmnt   .         Nx          Vy         Vz");
    fprintf(fp,"        Txx        Myy        Mzz\n");

    // write header information for each frame element to CSV output data file
    fprintf(fpcsv,"\n\"P E A K   F R A M E   E L E M E N T   I N T E R N A L   F O R C E S ");
    fprintf(fpcsv,"   (local)\",\n");
    fprintf(fpcsv," \"Elmnt\",  \".\", \"Nx\", \"Vy\", \"Vz\", ");
    fprintf(fpcsv," \"Txx\", \"Myy\", \"Mzz\", \n");


/*	fprintf(fp,"\n P E A K   I N T E R N A L   D I S P L A C E M E N T S");
 *	fprintf(fp,"\t\t\t(local)\n");
 * 	fprintf(fp,"  Elmnt  X-dsp       Y-dsp       Z-dsp       X-rot       Y-rot       Z-rot\n");
*/

    for ( m=1; m <= nE; m++ ) {	// loop over all frame elements

        n1 = J1[m];	n2 = J2[m]; // node 1 and node 2 of elmnt m

        nx = floor((L[m]/dx)+0.5);	// number of x-axis increments
        if (nx < 1) nx = 1;	// at least one x-axis increment

        float r1=Rj[n1];
        float r2=Rj[n2];

        int nx1=nx;

        if (r1>0) nx1++;
        if (r2>0) nx1++;

        ////here is a place to add extra abscissas based on abscissas_n and abscissas
        nx1 += abscissas_n[m-1];
        ////

        // allocate memory for interior force data for frame element "m"
        x  = dvector(0,nx1);
        Nx = dvector(0,nx1);
        Vy = dvector(0,nx1);
        Vz = dvector(0,nx1);
        Tx = dvector(0,nx1);
        My = dvector(0,nx1);
        Mz = dvector(0,nx1);
        Sy = dvector(0,nx1);
        Sz = dvector(0,nx1);
        Rx = dvector(0,nx1);
        Dx = dvector(0,nx1);
        Dy = dvector(0,nx1);
        Dz = dvector(0,nx1);

        Mzt = dvector(0,nx1);
        Myt = dvector(0,nx1);
        Dyt = dvector(0,nx1);
        Dzt = dvector(0,nx1);

        // the local x-axis for frame element "m" starts at 0 and ends at L[m]

        for (i=0; i<nx; i++)	x[i] = i*dx;
        x[nx] = L[m];

        ////dxnx = x[nx]-x[nx-1];	// length of the last x-axis increment

        int ii;
        int ai=0;
        double x1, x2;
        if (r1>0)
        {
            x1=r1;
            for (ii=0; ii<nx; ii++) if (Check_if_Equal(x1, x[ii])) break;
            if (ii==nx)
            {
                nx++;
                x[nx]=x1;
            }
        }
        if (r2>0)
        {
            x2=L[m]-r2;
            for (ii=0; ii<nx; ii++) if (Check_if_Equal(x2, x[ii])) break;
            if (ii==nx)
            {
                nx++;
                x[nx]=x2;
            }
        }

        ////here is a place to add extra abscissas based on abscissas_n and abscissas
        for (ii=0; ii<abscissas_n[m-1]; ii++)
        {
            nx++;
            x[nx]=abscissas[m-1][ii];
        }
        //now we have to eliminate doubles
        ////

#ifdef __unix__
        qsort(&x[0], nx+1, sizeof(double), (__compar_fn_t) qsort_by_val);   ////
#else
        qsort(&x[0], nx+1, sizeof(double), qsort_by_val);   ////
#endif

        nx = removeDuplicates(x, nx+1);

        // write header information for each frame element

        fprintf(fpif,"#\tElmnt\tN1\tN2        \tX1        \tY1        \tZ1        \tX2        \tY2        \tZ2\tnx\n");
        fprintf(fpif,"# @\t%5d\t%5d\t%5d\t%14.6e\t%14.6e\t%14.6e\t%14.6e\t%14.6e\t%14.6e\t%5d\n",m, n1, n2, xyz[n1].x, xyz[n1].y, xyz[n1].z, xyz[n2].x, xyz[n2].y, xyz[n2].z, nx + 1);
        ////fprintf(fpif,"THERMAL MOMENTS\t%14.6e\t%14.6e\n",Mzt[0],Mzt[nx]);


        // find interior axial force, shear forces, torsion and bending moments

        coord_trans ( xyz, L[m], n1, n2,
                      &t1, &t2, &t3, &t4, &t5, &t6, &t7, &t8, &t9, p[m] );

        // distributed gravity load in local x, y, z coordinates
        wxg = d[m]*Ax[m]*(t1*gX + t2*gY + t3*gZ);
        wyg = d[m]*Ax[m]*(t4*gX + t5*gY + t6*gZ);
        wzg = d[m]*Ax[m]*(t7*gX + t8*gY + t9*gZ);

        // add uniformly-distributed loads to gravity load
        for (n=1; n<=nE && cU<nU; n++) {
            if ( (int) U[n][1] == m ) { // load n on element m
                wxg += U[n][2];
                wyg += U[n][3];
                wzg += U[n][4];
                ++cU;
            }
        }

        /*
		// interior forces for frame element "m" at (x=0)
		Nx[0] = -Q[m][1];	// positive Nx is tensile
		Vy[0] = -Q[m][2];	// positive Vy in local y direction
		Vz[0] = -Q[m][3];	// positive Vz in local z direction
		Tx[0] = -Q[m][4];	// positive Tx r.h.r. about local x axis
		My[0] =  Q[m][5];	// positive My -> positive x-z curvature
        ////if fixed-fixed element or fixed-pin element
		Mz[0] = -Q[m][6];	// positive Mz -> positive x-y curvature

        ////by MAREK
        ////Mz[nx] = Q[m][12];  //for pin-fixed  //ALERT
        Mz[nx] = -Q[m][12];  //for pin-fixed  //ALERT  //WARNING  03-05-2026

        Mzt[0] = -Qt[m][6];
        Mzt[nx] = Qt[m][12];

        Myt[0] = -Qt[m][5];
        Myt[nx] = Qt[m][11];
         */

        // =================================================================
        // KINEMATIC BOUNDARY INITIALIZATION (MAREK RECOVERY MECHANICS)
        // =================================================================
        Nx[0] = -Q[m][1]; // tensile force boundary state
        Vy[0] = -Q[m][2]; // local y-axis shear boundary state
        Vz[0] = -Q[m][3]; // local z-axis shear boundary state
        Tx[0] = -Q[m][4]; // torsional torque boundary state

        // --- Z-Plane (Mz) Boundary State Router ---
        if (n1z[m] == 0 && n2z[m] == 1) {
            // Pinned-Rigid (0-1): Start from the active solver joint value
            Mz[0] = -Q[m][6];
        }
        else if (n1z[m] == 1 && n2z[m] == 0) {
            // Rigid-Pinned (1-0): Anchor the rigid root
            Mz[0] = -Q[m][6];
        }
        else if (n1z[m] == 0 && n2z[m] == 0) {
            // Pinned-Pinned (0-0): Clear span base initialization
            Mz[0] = -Q[m][6];
        }
        else {
            // Standard Fixed-Fixed (1-1)
            Mz[0] = -Q[m][6];
        }

        // --- Y-Plane (My) Symmetrical Boundary State Router ---
        if (n1y[m] == 0 && n2y[m] == 1) {
            My[0] =  Q[m][5];
        }
        else if (n1y[m] == 1 && n2y[m] == 0) {
            My[0] =  Q[m][5];
        }
        else if (n1y[m] == 0 && n2y[m] == 0) {
            My[0] =  Q[m][5];
        }
        else {
            My[0] =  Q[m][5];
        }

        // Keep global thermal actions isolated on boundaries
        Mzt[0] = -Qt[m][6]; Mzt[nx] = Qt[m][12];
        Myt[0] = -Qt[m][5]; Myt[nx] = Qt[m][11];

        double Mz0=Mz[0];  //moment at the end of r1
        double Mz1=Mz[nx];  //moment at the beginning of r2
        double Vy0=Vy[0];  //positive Vy in local y direction at the end of r1
        double Vy1=-Q[m][8];  //positive Vy in local y direction at the beginning of r2

        double dx0_;

        ////dx_ = dx;
        for (i=1; i<=nx; i++) {	/*  accumulate interior span loads */

            // start with gravitational plus uniform loads
            wx = wxg;
            wy = wyg;
            wz = wzg;

            if (i==1) {
                wx_ = wxg;
                wy_ = wyg;
                wz_ = wzg;
                tx_ = tx;
            }

            // add trapezoidally-distributed loads
            for (n=1; n<=10*nE && cW<nW; n++) {
                if ( (int) W[n][1] == m ) { // load n on element m
                    if (i==nx) ++cW;
                    xx1 = W[n][2];  xx2 = W[n][3];
                    wx1 = W[n][4];  wx2 = W[n][5];
                    xy1 = W[n][6];  xy2 = W[n][7];
                    wy1 = W[n][8];  wy2 = W[n][9];
                    xz1 = W[n][10]; xz2 = W[n][11];
                    wz1 = W[n][12]; wz2 = W[n][13];

                    if ( x[i]>xx1 && x[i]<=xx2 )
                        wx += wx1+(wx2-wx1)*(x[i]-xx1)/(xx2-xx1);
                    if ( x[i]>xy1 && x[i]<=xy2 )
                        wy += wy1+(wy2-wy1)*(x[i]-xy1)/(xy2-xy1);
                    if ( x[i]>xz1 && x[i]<=xz2 )
                        wz += wz1+(wz2-wz1)*(x[i]-xz1)/(xz2-xz1);
                }
            }

            // trapezoidal integration of distributed loads
            // for axial forces, shear forces and torques
            //if (i==nx)	dx_ = dxnx;
            dx0_=x[i]-x[i-1]; ////
            if (i<nx) dx_=x[i+1]-x[i]; ////
            else dx_=0;
            ////dx_=x[i]-x[i-1]; ////


            ////    Nx[i] = Nx[i - 1] - 0.5 * (wx + wx_) * dx_;
            ////    Vy[i] = Vy[i - 1] - 0.5 * (wy + wy_) * dx_;
            ////    Vz[i] = Vz[i - 1] - 0.5 * (wz + wz_) * dx_;
            ////    Tx[i] = Tx[i - 1] - 0.5 * (tx + tx_) * dx_;

            ////if ((i>0) && (i<=nx))
            ////{
            Nx[i] = Nx[i - 1] - 0.5 * (wx + wx_) * dx0_;
            Vy[i] = Vy[i - 1] - 0.5 * (wy + wy_) * dx0_;
            Vz[i] = Vz[i - 1] - 0.5 * (wz + wz_) * dx0_;
            Tx[i] = Tx[i - 1] - 0.5 * (tx + tx_) * dx0_;
            ////}

            // update distributed loads at x[i-1]
            wx_ = wx;
            wy_ = wy;
            wz_ = wz;
            tx_ = tx;

            // add interior point loads
            for (n=1; n<=10*nE && cP<nP; n++) {
                if ( (int) P[n][1] == m )
                { // load n on element m
                    if (i==nx) ++cP;
                    xp = P[n][5];
                    if ( x[i] <= xp && xp < x[i]+dx_)
                    {
                        if (dx_>0)
                        {
                            Nx[i] -= P[n][2] * 0.5 * (1.0 - (xp-x[i])/dx_);
                            Vy[i] -= P[n][3] * 0.5 * (1.0 - (xp-x[i])/dx_);
                            Vz[i] -= P[n][4] * 0.5 * (1.0 - (xp-x[i])/dx_);
                        }
                    }
                    ////if ( x[i]-dx_ <= xp && xp < x[i] )
                    if ( x[i]-dx0_ <= xp && xp < x[i] )
                    {
                        if (dx_>0)
                        {
                            Nx[i] -= P[n][2] * 0.5 * (1.0 - (x[i] - dx0_ - xp) / dx0_);
                            Vy[i] -= P[n][3] * 0.5 * (1.0 - (x[i] - dx0_ - xp) / dx0_);
                            Vz[i] -= P[n][4] * 0.5 * (1.0 - (x[i] - dx0_ - xp) / dx0_);
                        }
                    }
                }
            }

        }
        // linear correction of forces for bias in trapezoidal integration
        double i_nx;
        for (i=1; i<=nx; i++) {
            i_nx=x[i]/L[m];
            Nx[i] -= (Nx[nx]-Q[m][7])  * i_nx; //i/nx;
            Vy[i] -= (Vy[nx]-Q[m][8])  * i_nx; //i/nx;
            Vz[i] -= (Vz[nx]-Q[m][9])  * i_nx; //i/nx;
            Tx[i] -= (Tx[nx]-Q[m][10]) * i_nx; //i/nx;
        }

        ////by MAREK
        if (((n1z[m]==1) && (n2z[m]==1)) || (n1z[m]==0) || (n2z[m]==0)) //both nodes are fixed, but also in this variant for all members
        {
            for (i = 1; i <= nx; i++) {
                dx_ = x[i] - x[i - 1];
                //if ((x[i] >= r1) && (x[i] <= (L[m] - r2)))
                Mz[i] = Mz[i - 1] - 0.5 * (Vy[i] + Vy[i - 1]) * dx_;
                //else if (x[i] < r1)
                //    Mz[i] = Mz[0];
                //else
                //    Mz[i] = Mz[nx];

                ////My[i] = My[i-1] - 0.5*(Vz[i]+Vz[i-1])*dx_;
            }
        }

        // trapezoidal integration of shear force for bending momemnt
        ////dx_ = dx;
        for (i=1; i<=nx; i++) {
            ////if (i==nx)	dx_ = dxnx;
            dx_=x[i]-x[i-1]; ////
            My[i] = My[i-1] - 0.5*(Vz[i]+Vz[i-1])*dx_;
        }

        /*
        else if (n1z[m]==1) //first node is fixed
        {
            for (i=1; i<=nx; i++) {
                dx_=x[i]-x[i-1];
                if ((x[i] >= r1) && (x[i] <= (L[m] - r2)))
                    Mz[i] = Mz[i - 1] - 0.5 * (Vy[i] + Vy[i - 1]) * dx_;
                else if (x[i] < r1)
                    Mz[i] = Mz[0];
                else
                    Mz[i] = Mz[nx];
            }
        }

        else if (n2z[m]==1) //second node is fixed
        {
            for (i = nx-1; i >= 0; i--)
            {
                dx_=x[i+1]-x[i];

                if (((x[i] >= r1)) && (x[i] <= (L[m] - r2)))
                    Mz[i] = Mz[i + 1] - 0.5 * (Vy[i] + Vy[i + 1]) * dx_;
                else if (x[i] < r1)
                    Mz[i] = Mz[0];
                    else Mz[i] = Mz[nx];
            }
        }
         */

        // linear correction of moments for bias in trapezoidal integration
        double i_nxh;

        int mz0=0, mz1=0;

        for (i=0; i<=nx; i++) {
            if (Check_if_Equal(x[i], r1)) {
                Mz0 = Mz[i];
                Vy0 = Vy[i];
                mz0 = 1;
            } else if (Check_if_Equal(x[i], L[m] - r2)) {
                Mz1 = Mz[i];
                Vy1 = Vy[i];
                mz1 = 1;
            }
        }

        /*
		for (i=0; i<=nx; i++)
        {
            i_nx = x[i] / L[m];
            i_nxh = (x[i] - r1) / (L[m] - r1 - r2);
            My[i] -= (My[nx] + Q[m][11]) * i_nx; //i/nx;

            if (((n1z[m] == 1) && (n2z[m] == 1)) || (n1z[m] == 0) || (n2z[m] == 0)) //both nodes are fixed, but also in this variant for all members
            {

                    Mz[i] -= (Mz[nx] - Q[m][12]) * i_nx; //i/nx;

                    //// removing thermal moment - it's just temporary
                    if ((n1z[m] == 0) && (n2z[m] == 1)) Mz[i] -= (Mzt[nx]-Mzt[0]) * (i_nx);  ////for hinged-rigid
                    else if ((n1z[m] == 1) && (n2z[m] == 0)) Mz[i] += (Mzt[nx]-Mzt[0]) * (1- i_nx);  ////for rigid-hinged

                    ////it could be the same done for My[i] moments in 3D systems
            }
        }
         */
        // =================================================================
        // UNIFIED ORIGINAL MOMENT CORRECTION PASS (MAREK ORDER OF SCRIPT)
        // =================================================================
        for (i = 0; i <= nx; i++) {
            i_nx = x[i] / L[m];
            i_nxh = (x[i] - r1) / (L[m] - r1 - r2);

            // --- Z-Plane (Mz) Original Conditional Logic ---
            if (((n1z[m] == 1) && (n2z[m] == 1)) || (n1z[m] == 0) || (n2z[m] == 0)) {
                Mz[i] -= (Mz[nx] - Q[m][12]) * i_nx;

                // Temporary thermal moment removal
                if ((n1z[m] == 0) && (n2z[m] == 1))      Mz[i] -= (Mzt[nx] - Mzt[0]) * i_nx;
                else if ((n1z[m] == 1) && (n2z[m] == 0)) Mz[i] += (Mzt[nx] - Mzt[0]) * (1.0 - i_nx);
            }

            // --- My (Y-Plane) Symmetrically Conditioned Extension ---
            if (((n1y[m] == 1) && (n2y[m] == 1)) || (n1y[m] == 0) || (n2y[m] == 0)) {
                My[i] -= (My[nx] + Q[m][11]) * i_nx;

                // Symmetrical temporary thermal moment removal for My
                if ((n1y[m] == 0) && (n2y[m] == 1))      My[i] -= (Myt[nx] - Myt[0]) * i_nx;
                else if ((n1y[m] == 1) && (n2y[m] == 0)) My[i] += (Myt[nx] - Myt[0]) * (1.0 - i_nx);
            } else {
                // If it is a mixed member (0-1 or 1-0), mirror your original Mz behavior
                // and skip the linear correction pass entirely, letting global statics control it
                ;
            }
        }



        // find interior transverse displacements

        i1 = 6*(n1-1);	i2 = 6*(n2-1);

        /* compute end deflections in local coordinates */

        u1  = t1*D[i1+1] + t2*D[i1+2] + t3*D[i1+3];
        u2  = t4*D[i1+1] + t5*D[i1+2] + t6*D[i1+3];
        u3  = t7*D[i1+1] + t8*D[i1+2] + t9*D[i1+3];

        u4  = t1*D[i1+4] + t2*D[i1+5] + t3*D[i1+6];
        u5  = t4*D[i1+4] + t5*D[i1+5] + t6*D[i1+6];
        u6  = t7*D[i1+4] + t8*D[i1+5] + t9*D[i1+6];

        u7  = t1*D[i2+1] + t2*D[i2+2] + t3*D[i2+3];
        u8  = t4*D[i2+1] + t5*D[i2+2] + t6*D[i2+3];
        u9  = t7*D[i2+1] + t8*D[i2+2] + t9*D[i2+3];

        u10 = t1*D[i2+4] + t2*D[i2+5] + t3*D[i2+6];
        u11 = t4*D[i2+4] + t5*D[i2+5] + t6*D[i2+6];
        u12 = t7*D[i2+4] + t8*D[i2+5] + t9*D[i2+6];


        // rotations and displacements for frame element "m" at (x=0)
        //////////////
        /*
		Dx[0] =  u1;	// displacement in  local x dir  at node N1
		Dy[0] =  u2;	// displacement in  local y dir  at node N1
		Dz[0] =  u3;	// displacement in  local z dir  at node N1
		Rx[0] =  u4;	// rotationin about local x axis at node N1
        Sy[0] =  u6;	// slope in  local y  direction  at node N1
        ////   by MAREK
        Dy[nx] =  u8;	// displacement in  local y dir  at node N2
        Sy[nx] =  u12;	// slope in  local y  direction  at node N2
        ////
		Sz[0] = -u5;	// slope in  local z  direction  at node N1

		//MAREK
		//here axial displacement, transverse slope along and displacement along frame element must be corrected to nodes sizes, if  > 0.

		// axial displacement along frame element "m"
		////dx_ = dx;
		for (i=1; i<=nx; i++) {
			////if (i==nx)	dx_ = dxnx;
            dx_=x[i]-x[i-1]; ////
            if (((r1==0) || (x[i]>r1)) && ((r2==0) || (x[i]<L[m]-r2)))
                Dx[i] = Dx[i - 1] + 0.5 * (Nx[i - 1] + Nx[i]) / (E[m] * Ax[m]) * dx_;
            else
                Dx[i] = Dx[i - 1];
		}
		// linear correction of axial displacement for bias in trapezoidal integration
		for (i=1; i<=nx; i++) {
            i_nx=x[i]/L[m];
			Dx[i] -= (Dx[nx]-u7) * i_nx; //i/nx;
		}

		// torsional rotation along frame element "m"
		////dx_ = dx;
		for (i=1; i<=nx; i++) {
			////if (i==nx)	dx_ = dxnx;
            dx_=x[i]-x[i-1]; ////
			Rx[i] = Rx[i-1] + 0.5*(Tx[i-1]+Tx[i])/(G[m]*Jx[m])*dx_;
		}
		// linear correction of torsional rot'n for bias in trapezoidal integration
		for (i=1; i<=nx; i++) {
            i_nx=x[i]/L[m];
			Rx[i] -= (Rx[nx]-u10) * i_nx; //i/nx;
		}

        // transverse slope along frame element "m"
        for (i=1; i<=nx; i++) {
            dx_=x[i]-x[i-1];

            if (((r1==0) || (x[i]>r1)) && ((r2==0) || (x[i]<L[m]-r2)))
            {
                Sy[i] = Sy[i - 1] + 0.5 * (Mz[i - 1] + Mz[i]) / (E[m] * Iz[m]) * dx_;
                Sz[i] = Sz[i - 1] + 0.5 * (My[i - 1] + My[i]) / (E[m] * Iy[m]) * dx_;
            }
            else
            {
                Sy[i] = Sy[i - 1];
                Sz[i] = Sz[i - 1];
            }
        }
        // linear correction for bias in trapezoidal integration
        //double atansy=atan(Sy[nx] - u12);
        double atansy=(Sy[nx] - u12);
        for (i=1; i<=nx; i++) {
            i_nx=x[i]/L[m];
            if ((n1z[m]==1) && (n2z[m]==1)) Sy[i] -= (Sy[nx] - u12) * i_nx;   ////if rigid-rigid
            else if (n2z[m]==1)
                ;
            else if (n1z[m]==1)
                ;
            else
            {
                ; //Sy[i] -= (Sy[nx] - u12) * i_nx;
            }


            Sz[i] -= (Sz[nx] + u11) * i_nx; // i/nx;
        }
        if ( shear ) {		// add-in slope due to shear deformation
            for (i=0; i<=nx; i++) {
                if (((r1==0) || (x[i]>r1)) && ((r2==0) || (x[i]<L[m]-r2)))
                {
                    Sy[i] += Vy[i] / (G[m] * Asy[m]);
                    Sz[i] += Vz[i] / (G[m] * Asz[m]);
                }
            }
        }
        // displacement along frame element "m"

        for (i=1; i<=nx; i++) {
            dx_=x[i]-x[i-1];
            Dy[i] = Dy[i-1] + 0.5*(Sy[i-1]+Sy[i])*dx_;
            Dz[i] = Dz[i-1] + 0.5*(Sz[i-1]+Sz[i])*dx_;
        }
        // linear correction for bias in trapezoidal integration
        for (i=1; i<=nx; i++) {
            i_nx=x[i]/L[m];
            Dy[i] -= (Dy[nx] - u8) * i_nx; //i/nx;
            Dz[i] -= (Dz[nx] - u9) * i_nx; //i/nx;
        }
        */
        /////////////
        // =================================================================
        // RESTORED UNTRUNCATED DISPLACEMENT & SLOPE INTEGRATION
        // =================================================================

        // End deflections initialization
        Dx[0] =  u1; Dy[0] =  u2; Dz[0] =  u3;
        Rx[0] =  u4; Sy[0] =  u6; Sz[0] = -u5;
        Dy[nx] = u8; Sy[nx] = u12;

        // Axial displacement integration
        for (i = 1; i <= nx; i++) {
            dx_ = x[i] - x[i - 1];
            if (((r1 == 0) || (x[i] > r1)) && ((r2 == 0) || (x[i] < L[m] - r2)))
                Dx[i] = Dx[i - 1] + 0.5 * (Nx[i - 1] + Nx[i]) / (E[m] * Ax[m]) * dx_;
            else
                Dx[i] = Dx[i - 1];
        }
        for (i = 1; i <= nx; i++) Dx[i] -= (Dx[nx] - u7) * (x[i] / L[m]);

        // Torsional rotation integration
        for (i = 1; i <= nx; i++) {
            dx_ = x[i] - x[i - 1];
            Rx[i] = Rx[i - 1] + 0.5 * (Tx[i - 1] + Tx[i]) / (G[m] * Jx[m]) * dx_;
        }
        for (i = 1; i <= nx; i++) Rx[i] -= (Rx[nx] - u10) * (x[i] / L[m]);

        // Transverse slope integration
        for (i = 1; i <= nx; i++) {
            dx_ = x[i] - x[i - 1];
            if (((r1 == 0) || (x[i] > r1)) && ((r2 == 0) || (x[i] < L[m] - r2))) {
                Sy[i] = Sy[i - 1] + 0.5 * (Mz[i - 1] + Mz[i]) / (E[m] * Iz[m]) * dx_;
                Sz[i] = Sz[i - 1] + 0.5 * (My[i - 1] + My[i]) / (E[m] * Iy[m]) * dx_;
            } else {
                Sy[i] = Sy[i - 1]; Sz[i] = Sz[i - 1];
            }
        }

        // Transverse slope linear bias correction loop
        for (i = 1; i <= nx; i++) {
            i_nx = x[i] / L[m];

            // Z-Plane (Sy): Copied exactly from your working version
            if ((n1z[m] == 1) && (n2z[m] == 1))      Sy[i] -= (Sy[nx] - u12) * i_nx;
            else if (n2z[m] == 1)                    ;
            else if (n1z[m] == 1)                    ;
            else                                     ;

            // Y-Plane (Sz): Mirrored perfectly from your original Sy rules
            if ((n1y[m] == 1) && (n2y[m] == 1))      Sz[i] -= (Sz[nx] + u11) * i_nx;
            else if (n2y[m] == 1)                    ;
            else if (n1y[m] == 1)                    ;
            else                                     ;
        }

        if (shear) {
            for (i = 0; i <= nx; i++) {
                if (((r1 == 0) || (x[i] > r1)) && ((r2 == 0) || (x[i] < L[m] - r2))) {
                    Sy[i] += Vy[i] / (G[m] * Asy[m]);
                    Sz[i] += Vz[i] / (G[m] * Asz[m]);
                }
            }
        }

        // Deflection integration loops
        for (i = 1; i <= nx; i++) {
            dx_ = x[i] - x[i - 1];
            Dy[i] = Dy[i - 1] + 0.5 * (Sy[i - 1] + Sy[i]) * dx_;
            Dz[i] = Dz[i - 1] + 0.5 * (Sz[i - 1] + Sz[i]) * dx_;
        }
        for (i = 1; i <= nx; i++) {
            i_nx = x[i] / L[m];
            Dy[i] -= (Dy[nx] - u8) * i_nx;
            Dz[i] -= (Dz[nx] - u9) * i_nx;
        }

        ///extra displacement due to thermal load


        /*
        ////////// this is actually not necessary
        double Mztd=Mzt[nx]-Mzt[0];
        for (int ii=1; ii<nx; ii++)
        {
            i_nx = x[ii] / L[m];
            Mzt[ii]=Mzt[0]+Mztd*i_nx;
        }
        ////
        if ((n1z[m]==0) && (n2z[m]==1)) ////hinged-rigid
        {
            for (i = 1; i < nx; i++)
            {
                Dy[i] += (Mzt[nx]/(6.*E[m]*Iz[m]*L[m]))*((x[i]*x[i]*x[i]) - (2.*x[i]*x[i]*L[m]) + (L[m]*L[m]*x[i]));
                ////identical calculation could be done for Dz[i] using Myt[nx]
            }
            for (i = 0; i <= nx; i++) {
                i_nx = x[i] / L[m];
                ////restoring thermal moment
                Mz[i] += (Mzt[nx] - Mzt[0]) * (i_nx);  ////for hinged-rigid
                ////identical could be done for My[i], Myt[nx] and My[0]
            }

        }
        else if ((n2z[m]==0) && (n1z[m]==1)) ////rigid-hinged
        {
            for (i = 1; i < nx; i++)
            {
                Dy[i] -= (Mzt[0]/(6.*E[m]*Iz[m]*L[m]))*((x[i]*x[i]*x[i]) - (L[m]*x[i]*x[i]));
                ////identical calculation could be done for Dz[i] using Myt[0]
            }
            for (i = 0; i <= nx; i++) {
                i_nx = x[i] / L[m];
                ////restoring thermal moment
                Mz[i] -= (Mzt[nx]-Mzt[0]) * (1- i_nx);  ////for rigid-hinged
                ////identical could be done for My[i], Myt[nx] and My[0]
            }
        }
        else if ((n1z[m]==0) && (n2z[m]==0)) ////hinged-hinged
        {
            if (Qt[m][13]!=0.0) {
                for (i = 1; i < nx; i++) {
                   Dy[i] -= (Qt[m][13] * x[i] * (L[m] - x[i]));
                }
            }
            ////identical calculation could be done for Dz[i] using Qt[m][14]
        }
         */
        // =================================================================
        // THERMAL LOADING PROFILE RESTORATIONS (MAREK ORIGINAL)
        // =================================================================
        double Mztd = Mzt[nx] - Mzt[0];
        double Mytd = Myt[nx] - Myt[0];
        for (int ii = 1; ii < nx; ii++) {
            i_nx = x[ii] / L[m];
            Mzt[ii] = Mzt[0] + Mztd * i_nx;
            Myt[ii] = Myt[0] + Mytd * i_nx;
        }

        // --- Z-Plane (Dy & Mz) Restorations ---
        if ((n1z[m] == 0) && (n2z[m] == 1)) {
            for (i = 1; i < nx; i++) Dy[i] += (Mzt[nx] / (6. * E[m] * Iz[m] * L[m])) * ((x[i] * x[i] * x[i]) - (2. * x[i] * x[i] * L[m]) + (L[m] * L[m] * x[i]));
            for (i = 0; i <= nx; i++) Mz[i] += (Mzt[nx] - Mzt[0]) * (x[i] / L[m]);
        }
        else if ((n2z[m] == 0) && (n1z[m] == 1)) {
            for (i = 1; i < nx; i++) Dy[i] -= (Mzt[0] / (6. * E[m] * Iz[m] * L[m])) * ((x[i] * x[i] * x[i]) - (L[m] * x[i] * x[i]));
            for (i = 0; i <= nx; i++) Mz[i] -= (Mzt[nx] - Mzt[0]) * (1.0 - (x[i] / L[m]));
        }
        else if ((n1z[m] == 0) && (n2z[m] == 0)) {
            if (Qt[m][13] != 0.0) for (i = 1; i < nx; i++) Dy[i] -= (Qt[m][13] * x[i] * (L[m] - x[i]));
        }

        // --- Y-Plane (Dz & My) Symmetrical Restorations ---
        if ((n1y[m] == 0) && (n2y[m] == 1)) {
            for (i = 1; i < nx; i++) Dz[i] += (Myt[nx] / (6. * E[m] * Iy[m] * L[m])) * ((x[i] * x[i] * x[i]) - (2. * x[i] * x[i] * L[m]) + (L[m] * L[m] * x[i]));
            for (i = 0; i <= nx; i++) My[i] += (Myt[nx] - Myt[0]) * (x[i] / L[m]);
        }
        else if ((n2y[m] == 0) && (n1y[m] == 1)) {
            for (i = 1; i < nx; i++) Dz[i] -= (Myt[0] / (6. * E[m] * Iy[m] * L[m])) * ((x[i] * x[i] * x[i]) - (L[m] * x[i] * x[i]));
            for (i = 0; i <= nx; i++) My[i] -= (Myt[nx] - Myt[0]) * (1.0 - (x[i] / L[m]));
        }
        else if ((n1y[m] == 0) && (n2y[m] == 0)) {
            if (Qt[m][14] != 0.0) for (i = 1; i < nx; i++) Dz[i] -= (Qt[m][14] * x[i] * (L[m] - x[i]));
        }
        /////////////////////////

        // initialize the maximum and minimum element forces and displacements
        maxNx = minNx = Nx[0]; maxVy = minVy = Vy[0]; maxVz = minVz = Vz[0];  	//  maximum internal forces
        maxTx = minTx = Tx[0]; maxMy = minMy = My[0]; maxMz = minMz = Mz[0]; 	//  maximum internal moments
        maxDx = minDx = Dx[0]; maxDy = minDy = Dy[0]; maxDz = minDz = Dz[0]; 	//  maximum element displacements
        maxRx =	minRx = Rx[0]; maxSy = minSy = Sy[0]; maxSz = minSz = Sz[0];	//  maximum element rotations

        //maxMzt = minMzt = Mzt[0];

        // find maximum and minimum internal element forces
        for (i=1; i<=nx; i++) {
            maxNx = (Nx[i] > maxNx) ? Nx[i] : maxNx;
            minNx = (Nx[i] < minNx) ? Nx[i] : minNx;
            maxVy = (Vy[i] > maxVy) ? Vy[i] : maxVy;
            minVy = (Vy[i] < minVy) ? Vy[i] : minVy;
            maxVz = (Vz[i] > maxVz) ? Vz[i] : maxVz;
            minVz = (Vz[i] < minVz) ? Vz[i] : minVz;

            maxTx = (Tx[i] > maxTx) ? Tx[i] : maxTx;
            minTx = (Tx[i] < minTx) ? Tx[i] : minTx;
            maxMy = (My[i] > maxMy) ? My[i] : maxMy;
            minMy = (My[i] < minMy) ? My[i] : minMy;

            maxMz = (Mz[i] > maxMz) ? Mz[i] : maxMz;
            minMz = (Mz[i] < minMz) ? Mz[i] : minMz;

        }

        //maxMzt = (Mzt[0] > maxMzt) ? Mz[0] : maxMzt;
        //minMzt = (Mzt[i] < minMz) ? Mz[i] : minMz;

        // find maximum and minimum internal element displacements
        for (i=1; i<=nx; i++) {
            maxDx = (Dx[i] > maxDx) ? Dx[i] : maxDx;
            minDx = (Dx[i] < minDx) ? Dx[i] : minDx;
            maxDy = (Dy[i] > maxDy) ? Dy[i] : maxDy;
            minDy = (Dy[i] < minDy) ? Dy[i] : minDy;
            maxDz = (Dz[i] > maxDz) ? Dz[i] : maxDz;
            minDz = (Dz[i] < minDz) ? Dz[i] : minDz;
            maxRx = (Rx[i] > maxRx) ? Rx[i] : maxRx;
            minRx = (Rx[i] < minRx) ? Rx[i] : minRx;
            maxSy = (Sy[i] > maxSy) ? Sy[i] : maxSy;
            minSy = (Sy[i] < minSy) ? Sy[i] : minSy;
            maxSz = (Sz[i] > maxSz) ? Sz[i] : maxSz;
            minSz = (Sz[i] < minSz) ? Sz[i] : minSz;
        }

        // write associated moments of thermal load
        fprintf(fpif,"# THERMAL MOMENTS\t%14.6e\t%14.6e\n",Mzt[0],Mzt[nx]);
        // write max and min element forces to the internal frame element force output data file
        fprintf(fpif,"#                \tNx        \tVy        \tVz        \tTx        \tMy        \tMz        \tDx        \tDy        \tDz         \tRx\t*\n");
        fprintf(fpif,"# MAXIMUM\t%14.6e\t%14.6e\t%14.6e\t%14.6e\t%14.6e\t%14.6e\t%14.6e\t%14.6e\t%14.6e\t%14.6e\n", maxNx,maxVy,maxVz,maxTx,maxMy,maxMz,maxDx,maxDy,maxDz,maxRx );
        fprintf(fpif,"# MINIMUM\t%14.6e\t%14.6e\t%14.6e\t%14.6e\t%14.6e\t%14.6e\t%14.6e\t%14.6e\t%14.6e\t%14.6e\n", minNx,minVy,minVz,minTx,minMy,minMz,minDx,minDy,minDz,minRx );


        // write results to the internal frame element force output data file
        fprintf(fpif,"#.x                \tNx        \tVy        \tVz        \tTx       \tMy        \tMz        \tDx        \tDy        \tDz        \tRx\t~\n");
        for (i=0; i<=nx; i++) {
            fprintf(fpif,"%14.6e\t", x[i] );
            fprintf(fpif,"%14.6e\t%14.6e\t%14.6e\t",
                    Nx[i], Vy[i], Vz[i] );
            fprintf(fpif,"%14.6e\t%14.6e\t%14.6e\t",
                    Tx[i], My[i], Mz[i] );
            fprintf(fpif,"%14.6e\t%14.6e\t%14.6e\t%14.6e\n",
                    Dx[i], Dy[i], Dz[i], Rx[i] );
        }
        fprintf(fpif,"#---------------------------------------\n\n\n");

        // write max and min element forces to the Frame3DD text output data file (with associated moments of thermal load)
        fprintf(fp," %5d   max  %10.3f  %10.3f %10.3f %10.3f %10.3f %10.3f\n",
                m, maxNx, maxVy, maxVz, maxTx, maxMy, maxMz );
        fprintf(fp," %5d   min  %10.3f  %10.3f %10.3f %10.3f %10.3f %10.3f\n",
                m, minNx, minVy, minVz, minTx, minMy, minMz );

        // write max and min element forces to the Frame3DD CSV output data file
        fprintf(fpcsv," %5d, \"max\", %10.3f,  %10.3f, %10.3f, %10.3f, %10.3f, %10.3f\n",
                m, maxNx, maxVy, maxVz, maxTx, maxMy, maxMz );
        fprintf(fpcsv," %5d, \"min\", %10.3f,  %10.3f, %10.3f, %10.3f, %10.3f, %10.3f\n",
                m, minNx, minVy, minVz, minTx, minMy, minMz );

/*
		fprintf(fp," %5d %10.6f  %10.6f  %10.6f  %10.6f  %10.6f  %10.6f\n",
				m, maxDx, maxDy, maxDz, maxRx, maxSy, maxSz );
		fprintf(fp," %5d %10.6f  %10.6f  %10.6f  %10.6f  %10.6f  %10.6f\n",
				m, minDx, minDy, minDz, minRx, minSy, minSz );
*/

        // free memory
        free_dvector(x,0,nx);
        free_dvector(Nx,0,nx);
        free_dvector(Vy,0,nx);
        free_dvector(Vz,0,nx);
        free_dvector(Tx,0,nx);
        free_dvector(My,0,nx);
        free_dvector(Mz,0,nx);
        free_dvector(Rx,0,nx);
        free_dvector(Sy,0,nx);
        free_dvector(Sz,0,nx);
        free_dvector(Dx,0,nx);
        free_dvector(Dy,0,nx);
        free_dvector(Dz,0,nx);

        free_dvector(Mzt,0,nx);
        free_dvector(Myt,0,nx);
        free_dvector(Dyt,0,nx);
        free_dvector(Dzt,0,nx);

    }				// end of loop over all frame elements

    fclose(fpif);
    fclose(fpcsv);
}