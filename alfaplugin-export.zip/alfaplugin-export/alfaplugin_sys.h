//
// Created by marek on 2/2/24.
//

#ifndef LIBFUN_PL_H_ALFAPLUGIN_SYS_H
#define LIBFUN_PL_H_ALFAPLUGIN_SYS_H

typedef enum {ENGLISH = 0, POLISH, UKRAINIAN, SPANISH} languages;

#define MAXPATH   260
#define MAXDIR	  256

#define _USE_MATH_DEFINES

#endif //LIBFUN_PL_H_ALFAPLUGIN_SYS_H
