#ifndef __APP_FUNCS_H__
#define __APP_FUNCS_H__

int the_num_get(void);
int the_num_set(int a);

#endif /* __APP_FUNCS_H__ */
