import os
import sys
from PIL import Image

if len(sys.argv) < 4:
    print("Usage: python script.py <input.bmp> <output.ext> <dpi>")
    sys.exit(1)

Image.MAX_IMAGE_PIXELS = None
infile = sys.argv[1]
outfile = sys.argv[2]

try:
    hdpi = int(sys.argv[3])
except ValueError:
    print("Error: DPI must be an integer.")
    sys.exit(1)

f, e = os.path.splitext(outfile)
img_format = e.replace('.', '').upper()

# Standardization Map
format_map = {'JPG': 'JPEG', 'TIF': 'TIFF'}
img_format = format_map.get(img_format, img_format)

try:
    with Image.open(infile) as im:
        # --- Format Specific Logic ---
        
        # 1. JPEG & PCX: No Transparency/Palettes
        if img_format in ["JPEG", "PCX"]:
            if im.mode in ("RGBA", "P", "LA"):
                im = im.convert("RGB")
            elif im.mode == "1":
                im = im.convert("L")

        # 2. EPS & PDF: These often require RGB or CMYK
        # BMPs are often 'P' (Palette) or 'RGB'. 
        # EPS/PDF save better when explicitly RGB.
        if img_format in ["EPS", "PDF"]:
            if im.mode in ("RGBA", "P", "LA"):
                im = im.convert("RGB")

        # 3. TIFF: High compatibility
        # No changes needed, but we keep the DPI.

        print(f"Converting {im.mode} -> {img_format} ({hdpi} DPI)")
        
        # Save logic
        # Note: 'jfif_density' is removed as it's only for JPEG and can break PDF/EPS saves.
        im.save(outfile, format=img_format, dpi=(hdpi, hdpi))
        print(f"Success: {outfile}")

except Exception as e:
    print(f"Error converting {infile}: {e}")
