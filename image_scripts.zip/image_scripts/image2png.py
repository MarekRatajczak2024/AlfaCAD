import os
import sys
from PIL import Image

# 1. Safety Check: Ensure the user provided the required file paths
if len(sys.argv) < 3:
    print("Usage: python script.py <input_file> <output_name> [mode]")
    print("Modes: 1 (B&W), L (Grayscale), P (Palette)")
    sys.exit(1)

# Remove image size limits for large files
Image.MAX_IMAGE_PIXELS = None

# 2. Assign Parameters
infile = sys.argv[1]
outfile_raw = sys.argv[2]
modes = ['1', 'L', 'P']

# Determine bitperpxl (defaults to 'P' if not specified or invalid)
if len(sys.argv) > 3 and sys.argv[3] in modes:
    bitperpxl = sys.argv[3]
    apply_conversion = True
else:
    bitperpxl = 'P'
    apply_conversion = False # Set to True if you want to force 'P' mode by default

# 3. Handle File Extensions
f, e = os.path.splitext(outfile_raw)
outfile = f + ".png"

# Prevent the script from trying to open and save to the same path
if os.path.abspath(infile) == os.path.abspath(outfile):
    print("Error: Input and output files must have different names.")
    sys.exit(1)

try:
    with Image.open(infile) as im:
        # Apply mode conversion if requested (e.g., converting to 8-bit Palette)
        if apply_conversion:
            print(f"Converting image mode to: {bitperpxl}")
            im = im.convert(bitperpxl)
        
        # Set default DPI if it's missing (PNG uses a tuple for DPI)
        # Note: PNGs technically store density in meters, Pillow handles the conversion.
        if 'dpi' not in im.info:
            im.info['dpi'] = (300, 300)
        
        print(f"Original Metadata: {im.info}")

        # 4. Save as PNG
        # PNG doesn't use 'jfif_density'; that is a JPEG-specific setting.
        im.save(outfile, format='PNG', dpi=im.info['dpi'])
        print(f"Successfully saved: {outfile}")

    # 5. Verify the saved file
    with Image.open(outfile) as im_check:
        print(f"Verified PNG Info: {im_check.info}")

except FileNotFoundError:
    print(f"Error: The file '{infile}' was not found.")
except Exception as e:
    print(f"An unexpected error occurred: {e}")
