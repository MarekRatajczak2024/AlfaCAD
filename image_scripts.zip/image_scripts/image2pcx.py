import os
import sys
from PIL import Image

# 1. Argument Check
if len(sys.argv) < 3:
    print("Usage: python script.py <input_file> <output_name> [mode]")
    print("Available PCX Modes: 1 (B&W), L (Grayscale), P (Palette), RGB")
    sys.exit(1)

Image.MAX_IMAGE_PIXELS = None

# 2. Parameters
infile = sys.argv[1]
outfile_raw = sys.argv[2]
requested_mode = sys.argv[3] if len(sys.argv) > 3 else 'P'

# PCX supports 1, L, P, and RGB. 
valid_modes = ['1', 'L', 'P', 'RGB']
if requested_mode not in valid_modes:
    requested_mode = 'P'

# 3. Path Handling
f, e = os.path.splitext(outfile_raw)
outfile = f + ".pcx"

# Prevent overwriting source
if os.path.abspath(infile) == os.path.abspath(outfile):
    print("Error: Input and output paths are the same.")
    sys.exit(1)

try:
    with Image.open(infile) as im:
        # PCX conversion - it's best to explicitly convert to a compatible mode
        print(f"Converting {infile} ({im.mode}) to PCX ({requested_mode})...")
        im_converted = im.convert(requested_mode)
        
        # Handle DPI
        # PCX stores DPI as an integer. Defaulting to 300 if not found.
        dpi_val = im.info.get('dpi', (300, 300))
        
        # 4. Save
        # PCX does not use 'jfif_density' (that is for JPEG only)
        im_converted.save(outfile, format='PCX', dpi=dpi_val)
        print(f"Successfully saved to {outfile}")

    # 5. Verification
    with Image.open(outfile) as im_check:
        print(f"Verified PCX Info: {im_check.size} {im_check.mode} DPI: {im_check.info.get('dpi')}")

except FileNotFoundError:
    print(f"Error: File '{infile}' not found.")
except Exception as e:
    print(f"An error occurred during conversion: {e}")
