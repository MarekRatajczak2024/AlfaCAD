import os
import sys
from PIL import Image

# 1. Check if arguments were actually provided
if len(sys.argv) < 3:
    print("Usage: python script.py <input_file> <output_name> [mode]")
    sys.exit(1)

Image.MAX_IMAGE_PIXELS = None
modes = ['1', 'L', 'P']

infile = sys.argv[1]
outfile_raw = sys.argv[2]

# Handle optional bitperpxl
bitperpxl = sys.argv[3] if len(sys.argv) > 3 and sys.argv[3] in modes else 'P'

# Ensure output ends in .jpg
f, e = os.path.splitext(outfile_raw)
outfile = f + ".jpg"

if infile == outfile:
    print("Error: Input and output files cannot have the same name.")
    sys.exit(1)

try:
    with Image.open(infile) as im0:
        print(f"Original Info: {im0.info}")
        
        # Convert to RGB (required for JPEG)
        im = im0.convert('RGB')
        
        # Default DPI if missing
        dpi_value = im.info.get('dpi', (300, 300))
        
        im.save(outfile, format='JPEG', dpi=dpi_value, jfif_density=dpi_value)
        print(f"Successfully saved to {outfile}")

    # Verify the saved file
    with Image.open(outfile) as im_check:
        print(f"Final Image Info: {im_check.info}")
        
except Exception as e:
    print(f"Failed to convert {infile}. Error: {e}")
