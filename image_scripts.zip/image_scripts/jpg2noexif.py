import os
import sys
from PIL import Image

# Disables safety limits for giant files
Image.MAX_IMAGE_PIXELS = None

if len(sys.argv) < 3:
    print("Usage: python script.py input.jpg output.jpg")
    sys.exit(1)

infile = sys.argv[1]
outfile = sys.argv[2]

# Force .jpg extension on the output name
f, _ = os.path.splitext(outfile)
outfile = f + ".jpg"

# Prevent overwriting the original file by accident
if os.path.abspath(infile) == os.path.abspath(outfile):
    print("Error: Input and output files cannot be the same.")
    sys.exit(1)

try:
    with Image.open(infile) as im:
        # Fallback DPI if missing in original image
        dpi = im.info.get('dpi', (300, 300))
        
        # EXIF is stripped by default when saving, UNLESS you pass exif=im.info['exif'].
        # We handle palette images ('P') properly by converting or preserving them.
        if im.mode == 'P':
            im = im.convert('RGB')

        # Save without copying pixels manually (100x faster and memory efficient)
        im.save(
            outfile, 
            format='JPEG', 
            dpi=dpi, 
            jfif_density=dpi,
            quality=95  # Keeps image quality high
        )
        print(f"Successfully stripped EXIF: {outfile}")

except IOError as e:
    print(f"Cannot convert {infile}. Error: {e}")
