#!/usr/bin/env python
import sys, os

import wx
import wx.adv
import wx.lib.inspection
import wx.lib.mixins.inspection

from sys import platform


pid = os.getpid()
#pip3 install -U PyObjC

#if platform == "linux" or platform == "linux2":
    # linux
#elif platform == "darwin":
    # OS X
#elif platform == "win32":
    # Windows...

if platform == "darwin":
    try:
        import AppKit

        info = AppKit.NSBundle.mainBundle().infoDictionary()
        info['LSUIElement'] = '1'
    except:
        pass
    
    try:    
        from Cocoa import NSApp, NSApplication
    except:
        pass

assertMode = wx.APP_ASSERT_DIALOG
##assertMode = wx.APP_ASSERT_EXCEPTION

client="1"
app=""
aTitle=""
aMessage=""
aDefaultInput=""
fontface=""
fontfile=""
fontsize=""
fontwidth=""
etype=""
params=""
bold=0
italics=0
underlined=0
adjust=0
hidden=0
single=0
geometry=""
width=800
height=600
origin_x=0
origin_y=0
TTF_path=""
OTF_path=""
newtext=1
global_cursor_pos=0
if platform == 'darwin':
    margin=0  #on Linux 13
else:
    margin=14
hscrollbar=1

lang=0

languages=["EN","PL","UA","ES"]

EXIT=["Exit without saving", "Wyjdź bez zapisywania", "Вийти без збереження", "Salir sin guardar"]
SAVE=["Save file and exit", "Zapisz plik i wyjdź", "Зберегти файл і вийти", "Guardar archivo y salir"]
HIDDEN=["Hidden", "Ukryty", "Прихований", "Oculto"]
UNDERLINED=["Underlined", "Podkreślony", "Підкреслений", "Subrayado"]
BOLD=["Bold", "Pogrubiony", "Жирний", "En negrita"]
ITALICS=["Italics", "Kursywa", "Курсив", "Cursiva"]
ALIGN_LEFT=["Align left", "Wyrównaj do lewej", "Вирівняти за лівим", "Alinear a la izquierda"]
ALIGN_MIDDLE=["Align middle", "Wyrównaj do środka", "Вирівняти посередині", "Alinear el medio"]
ALIGN_CENTER=["Align center", "Wyrównaj do centrum", "Вирівняти по центру", "Alinear al centro"]
ALIGN_RIGHT=["Align right", "Wyrównaj do prawej", "Вирівняти по правому", "Alinear a la derecha"]
ESCAPE=["Escape", "Wyjdź", "Втеча", "Escapar"]
ENTER=["Enter", "Wprowadź", "Введіть", "Ingresar"]

#---------------------------------------------------------------------------

class Log:
    def WriteText(self, text):
        if text[-1:] == '\n':
            text = text[:-1]
        wx.LogMessage(text)
    write = WriteText
    
class ShapedButton(wx.PyControl):
    def __init__(self, parent, normal, pressed=None, disabled=None):
        super(ShapedButton, self).__init__(parent, -1, style=wx.BORDER_NONE)
        self.normal = normal
        self.pressed = pressed
        self.disabled = disabled
        self.region = wx.Region(normal, wx.Colour(0, 0, 0, 0))
        self._clicked = False
        self.SetBackgroundStyle(wx.BG_STYLE_CUSTOM)
        self.Bind(wx.EVT_SIZE, self.on_size)
        self.Bind(wx.EVT_PAINT, self.on_paint)
        self.Bind(wx.EVT_LEFT_DOWN, self.on_left_down)
        self.Bind(wx.EVT_LEFT_DCLICK, self.on_left_dclick)
        self.Bind(wx.EVT_LEFT_UP, self.on_left_up)
        self.Bind(wx.EVT_MOTION, self.on_motion)
        self.Bind(wx.EVT_LEAVE_WINDOW, self.on_leave_window)
    def DoGetBestSize(self):
        return self.normal.GetSize()
    def Enable(self, *args, **kwargs):
        super(ShapedButton, self).Enable(*args, **kwargs)
        self.Refresh()
    def Disable(self, *args, **kwargs):
        super(ShapedButton, self).Disable(*args, **kwargs)
        self.Refresh()
    def post_event(self):
        event = wx.CommandEvent()
        event.SetEventObject(self)
        event.SetEventType(wx.EVT_BUTTON.typeId)
        wx.PostEvent(self, event)
    def on_size(self, event):
        event.Skip()
        self.Refresh()
    def on_paint(self, event):
        dc = wx.AutoBufferedPaintDC(self)
        dc.SetBackground(wx.Brush(self.GetParent().GetBackgroundColour()))
        dc.Clear()
        bitmap = self.normal
        if self.clicked:
            bitmap = self.pressed or bitmap
        if not self.IsEnabled():
            bitmap = self.disabled or bitmap
        dc.DrawBitmap(bitmap, 0, 0)
    def set_clicked(self, clicked):
        if clicked != self._clicked:
            self._clicked = clicked
            self.Refresh()
    def get_clicked(self):
        return self._clicked
    clicked = property(get_clicked, set_clicked)
    def on_left_down(self, event):
        x, y = event.GetPosition()
        if self.region.Contains(x, y):
            self.clicked = True
    def on_left_dclick(self, event):
        self.on_left_down(event)
    def on_left_up(self, event):
        if self.clicked:
            x, y = event.GetPosition()
            if self.region.Contains(x, y):
                self.post_event()
        self.clicked = False
    def on_motion(self, event):
        if self.clicked:
            x, y = event.GetPosition()
            if not self.region.Contains(x, y):
                self.clicked = False
    def on_leave_window(self, event):
        self.clicked = False

class AlfaEditPanel(wx.Panel):

    def __init__(self, parent, log):
        global italics
        global bold
        global underlined
        global hidden
        global adjust
        global single
        global newtext
        global margin
        global hscrollbar
        global lang

        self.edited=0

        self.lang=lang

        wx.Panel.__init__(self, parent, -1)

        self.log = log

        self.leftDown = False
        self.parentFrame = parent
        while self.parentFrame.GetParent() is not None:
            self.parentFrame = self.parentFrame.GetParent()
        self.delta = wx.Point(0, 0)


        def scale_bitmap(bitmap, width, height, quality=wx.IMAGE_QUALITY_HIGH):
            """Scales a wx.Bitmap to a new size."""
            image = bitmap.ConvertToImage()
            image = image.Scale(width, height, quality)
            result = image.ConvertToBitmap()
            return result

        if single==1:
            if hscrollbar==1:
                te_style=wx.TE_MULTILINE | wx.TE_NO_VSCROLL | wx.TE_PROCESS_ENTER | wx.TE_DONTWRAP | wx.HSCROLL | wx.TE_CENTER
            else:
                te_style=wx.TE_MULTILINE | wx.TE_NO_VSCROLL & ~wx.HSCROLL | wx.TE_PROCESS_ENTER | wx.TE_DONTWRAP | wx.HSCROLL | wx.TE_CENTER
            te_size=(200, int(fontsize)+margin)
        else:
            te_style=wx.TE_MULTILINE | wx.TE_PROCESS_ENTER | wx.TE_DONTWRAP | wx.HSCROLL
            te_size=(200, 100)

        ##l3 = wx.StaticText(self, -1, "Multi-line")
        t3 = wx.TextCtrl(self, -1, value=aMessage, size=te_size, style=te_style)   #single or multiline text

        #t3.SetInsertionPoint(0)

        #points = t3.GetFont().GetPointSize()  # get the current size
        
        if platform!='darwin':
            filename = os.path.join(TTF_path, fontfile)
            try:
                wx.Font.AddPrivateFont(filename)
            except:
                filename = os.path.join(OTF_path, fontfile)
                wx.Font.AddPrivateFont(filename)
            else:
                pass
            finally:
                pass
        else:
            filename = fontfile
            #wx.Font.AddPrivateFont(filename)  #is ignore at the moment
        #font_pixel_size=SetPixelSize()

        #f = wx.Font(fontsize, wx.FONTFAMILY_ROMAN, wx.FONTSTYLE_ITALIC, wx.FONTWEIGHT_BOLD, False)
        #wx.FONTWEIGHT_NORMAL=400
        #wx.FONTWEIGHT_MEDIUM=500
        #wx.FONTWEIGHT_SEMIBOLD=600
        #wx.FONTWEIGHT_BOLD=700
        #wx.FONTWEIGHT_EXTRABOLD=800
        #wx.FONTWEIGHT_HEAVY=900
        #wx.FONTWEIGHT_EXTRAHEAVY=1000
        if (italics==0):
            styled=wx.FONTSTYLE_NORMAL
        else:
            styled=wx.FONTSTYLE_ITALIC
        if (bold==0):
            weighted=wx.FONTWEIGHT_SEMIBOLD
        else:
            weighted=wx.FONTWEIGHT_BOLD

        f = wx.Font(pixelSize=(wx.Size(int(fontwidth), int(fontsize))), family=wx.FONTFAMILY_DEFAULT, style=styled, weight=weighted, underline=underlined, faceName=fontface, encoding=wx.FONTENCODING_UTF8)

        t3.SetFont(f);

        t3.SetInsertionPoint(0)

        self.tc = t3

        t3.Bind(wx.EVT_KEY_DOWN, self.OnKeyDown, t3)
        t3.Bind(wx.EVT_KEY_UP, self.OnKeyUp, t3)
        t3.Bind(wx.EVT_CHAR, self.OnChar, t3)
        #self.Bind(wx.EVT_TEXT, self.EvtText, t3)
        self.Bind(wx.EVT_TEXT_ENTER, self.EvtTextEnter, t3)

        # create wx.Bitmap object
        bmp_Alt = wx.Bitmap('Bitmaps/PNG64/Alt1.png')
        bmp_Alt = scale_bitmap(bmp_Alt, 32, 32)
        self.bmp_Alt=bmp_Alt
        
        bmp_Alt1 = wx.Bitmap('Bitmaps/PNG64/Alt2.png')
        bmp_Alt1 = scale_bitmap(bmp_Alt1, 32, 32)
        self.bmp_Alt1=bmp_Alt1

        if etype=='FILE':
            bmp_save =  wx.Bitmap('Bitmaps/PNG64/ok_d_64.png')
            bmp_save = scale_bitmap(bmp_save, 32, 32)
            self.bmp_save=bmp_save

            bmp_escape =  wx.Bitmap('Bitmaps/PNG64/escape_d.png')
            bmp_escape = scale_bitmap(bmp_escape, 32, 32)
            self.bmp_escape=bmp_escape
        else:
            bmp_hidden =  wx.Bitmap('Bitmaps/PNG64/hidden_text.png')
            bmp_hidden = scale_bitmap(bmp_hidden, 28, 28)
            self.bmp_hidden=bmp_hidden
        
            bmp_hidden1 =  wx.Bitmap('Bitmaps/PNG64/hidden_text1.png')
            bmp_hidden1 = scale_bitmap(bmp_hidden1, 28, 28)
            self.bmp_hidden1=bmp_hidden1

            bmp_underlined = wx.Bitmap('Bitmaps/PNG64/underlined.png')
            bmp_underlined = scale_bitmap(bmp_underlined, 28, 28)
            self.bmp_underlined = bmp_underlined
                
            bmp_underlined1 = wx.Bitmap('Bitmaps/PNG64/underlined1.png')
            bmp_underlined1 = scale_bitmap(bmp_underlined1, 28, 28)
            self.bmp_underlined1 = bmp_underlined1

            bmp_bold = wx.Bitmap('Bitmaps/PNG64/bold.png')
            bmp_bold = scale_bitmap(bmp_bold, 28, 28)
            self.bmp_bold = bmp_bold
        
            bmp_bold1 = wx.Bitmap('Bitmaps/PNG64/bold1.png')
            bmp_bold1 = scale_bitmap(bmp_bold1, 28, 28)
            self.bmp_bold1 = bmp_bold1

            bmp_italics = wx.Bitmap('Bitmaps/PNG64/italic.png')
            bmp_italics = scale_bitmap(bmp_italics, 28, 28)
            self.bmp_italics = bmp_italics
        
            bmp_italics1 = wx.Bitmap('Bitmaps/PNG64/italic1.png')
            bmp_italics1 = scale_bitmap(bmp_italics1, 28, 28)
            self.bmp_italics1 = bmp_italics1

            if single==1:
                bmp_align_left = wx.Bitmap('Bitmaps/PNG64/text_align_baselineleft.png')
            else:
                bmp_align_left = wx.Bitmap('Bitmaps/PNG64/align-left.png')
            bmp_align_left = scale_bitmap(bmp_align_left, 28, 28)

            if single==1:
                bmp_align_center = wx.Bitmap('Bitmaps/PNG64/text_align_baselineleft.png')
            else:
                bmp_align_center = wx.Bitmap('Bitmaps/PNG64/align-center.png')
            bmp_align_center = scale_bitmap(bmp_align_center, 28, 28)

            if single==1:
                bmp_align_middlecenter = wx.Bitmap('Bitmaps/PNG64/text_align_middlecenter.png')
                bmp_align_middlecenter = scale_bitmap(bmp_align_middlecenter, 28, 28)

            if single==1:
                bmp_align_right = wx.Bitmap('Bitmaps/PNG64/text_align_baselineright.png')
            else:
                bmp_align_right = wx.Bitmap('Bitmaps/PNG64/align-right.png')
            bmp_align_right = scale_bitmap(bmp_align_right, 28, 28)

            bmp_Esc = wx.Bitmap('Bitmaps/PNG64/Esc.png')
            bmp_Esc = scale_bitmap(bmp_Esc, 32, 32)

            bmp_Enter = wx.Bitmap('Bitmaps/PNG64/enter128.png')
            bmp_Enter = scale_bitmap(bmp_Enter, 64, 32)

        b1 = wx.BitmapButton(self, id = 1, bitmap=bmp_Alt, style=wx.NO_BORDER|wx.BU_EXACTFIT, size =(36, 36),  name ="")
        b1.SetBitmap(bmp_Alt)
        #b1 = ShapedButton(self, wx.Bitmap('Bitmaps/Alt.png'), wx.Bitmap('Bitmaps/Esc.png'), wx.Bitmap('hidden_text.png'))
    
        b1.SetToolTip("Alt")
        self.Bind(wx.EVT_BUTTON, self.OnAlt, b1)
        self.b1=b1

        if etype=='FILE':
            b11 = wx.BitmapButton(self, id = 11, bitmap=bmp_escape, style=wx.NO_BORDER|wx.BU_EXACTFIT, size =(36, 36),  name ="")
            b11.SetBitmap(bmp_escape)
            b11.SetToolTip(EXIT[self.lang])
            self.Bind(wx.EVT_BUTTON, self.OnExit, b11)

            b12 = wx.BitmapButton(self, id = 12, bitmap=bmp_save, style=wx.NO_BORDER|wx.BU_EXACTFIT, size =(36, 36),  name ="")
            b12.SetBitmap(bmp_save)
            b12.SetToolTip(SAVE[self.lang])
            self.Bind(wx.EVT_BUTTON, self.OnSave, b12)
        else:
            b2 = wx.BitmapButton(self, id = 2, bitmap=bmp_hidden, style=wx.NO_BORDER|wx.BU_EXACTFIT, size =(36, 36),  name ="")
            if not hidden:
                b2.SetBitmap(bmp_hidden)
            else:
                b2.SetBitmap(bmp_hidden1)
            b2.SetToolTip(HIDDEN[self.lang])
            self.Bind(wx.EVT_BUTTON, self.OnHidden, b2)
            self.b2=b2

            b3 = wx.BitmapButton(self, id = 3, bitmap=bmp_underlined, style=wx.NO_BORDER|wx.BU_EXACTFIT, size =(36, 36),  name ="")
            if not underlined:
                b3.SetBitmap(bmp_underlined)
            else:
                b3.SetBitmap(bmp_underlined1)
            b3.SetToolTip(UNDERLINED[self.lang])
            self.Bind(wx.EVT_BUTTON, self.OnUnderlined, b3)
            self.b3=b3

            b4 = wx.BitmapButton(self, id = 4, bitmap=bmp_bold, style=wx.NO_BORDER|wx.BU_EXACTFIT, size =(36, 36),  name ="")
            if not bold:
                b4.SetBitmap(bmp_bold)
            else:
                b4.SetBitmap(bmp_bold1)
            b4.SetToolTip(BOLD[self.lang])
            self.Bind(wx.EVT_BUTTON, self.OnBold, b4)
            self.b4=b4

            b5 = wx.BitmapButton(self, id = 5, bitmap=bmp_italics, style=wx.NO_BORDER|wx.BU_EXACTFIT, size =(36, 36),  name ="")
            if not italics:
                b5.SetBitmap(bmp_italics)
            else:
                b5.SetBitmap(bmp_italics1)
            b5.SetToolTip(ITALICS[self.lang])
            self.Bind(wx.EVT_BUTTON, self.OnItalics, b5)
            self.b5=b5

            b6 = wx.BitmapButton(self, id = 6, bitmap=bmp_align_left, style=wx.NO_BORDER|wx.BU_EXACTFIT, size =(36, 36),  name ="")
            b6.SetBitmap(bmp_align_left)
            b6.SetToolTip(ALIGN_LEFT[self.lang])
            self.Bind(wx.EVT_BUTTON, self.OnAlignLeft, b6)

            b7 = wx.BitmapButton(self, id = 7, bitmap=bmp_align_center, style=wx.NO_BORDER|wx.BU_EXACTFIT, size =(36, 36),  name ="")
            b7.SetBitmap(bmp_align_center)
            b7.SetToolTip(ALIGN_MIDDLE[self.lang])
            self.Bind(wx.EVT_BUTTON, self.OnAlignCenter, b7)

            if single==1:
               b71 = wx.BitmapButton(self, id = 71, bitmap=bmp_align_middlecenter, style=wx.NO_BORDER|wx.BU_EXACTFIT, size =(36, 36),  name ="")
               b71.SetBitmap(bmp_align_middlecenter)
               b71.SetToolTip(ALIGN_CENTER[self.lang])
               self.Bind(wx.EVT_BUTTON, self.OnAlignMiddleCenter, b71)

            b8 = wx.BitmapButton(self, id = 8, bitmap=bmp_align_right, style=wx.NO_BORDER|wx.BU_EXACTFIT, size =(36, 36),  name ="")
            b8.SetBitmap(bmp_align_right)
            b8.SetToolTip(ALIGN_RIGHT[self.lang])
            self.Bind(wx.EVT_BUTTON, self.OnAlignRight, b8)

            b9 = wx.BitmapButton(self, id = 9, bitmap=bmp_Esc, style=wx.NO_BORDER|wx.BU_EXACTFIT, size =(36, 36),  name ="")
            b9.SetBitmap(bmp_Esc)
            b9.SetToolTip(ESCAPE[self.lang])
            self.Bind(wx.EVT_BUTTON, self.OnEsc, b9)

            b10 = wx.BitmapButton(self, id = 10, bitmap=bmp_Enter, style=wx.NO_BORDER|wx.BU_EXACTFIT, size =(68, 36),  name ="")
            b10.SetBitmap(bmp_Enter)
            b10.SetToolTip(ENTER[self.lang])
            self.Bind(wx.EVT_BUTTON, self.OnEnter, b10)

        self.tc = t3  #??????
        space = 2
        space_end = 10
        bsizer = wx.BoxSizer(wx.HORIZONTAL)
        bsizer.AddStretchSpacer();
        bsizer.Add(b1, 0, wx.GROW|wx.ALL, space)
        bsizer.Add((5,1), 0)
        if etype=='FILE':
            bsizer.Add(b11, 0, wx.GROW|wx.ALL, space)
            bsizer.Add(b12, 0, wx.GROW|wx.ALL, space)
        else:
            bsizer.Add(b2, 0, wx.GROW|wx.ALL, space)
            bsizer.Add(b3, 0, wx.GROW|wx.ALL, space)
            bsizer.Add(b4, 0, wx.GROW|wx.ALL, space)
            bsizer.Add(b5, 0, wx.GROW|wx.ALL, space)
            bsizer.Add(b6, 0, wx.GROW|wx.ALL, space)
            bsizer.Add(b7, 0, wx.GROW|wx.ALL, space)
            if single==1:
                bsizer.Add(b71, 0, wx.GROW|wx.ALL, space)
            bsizer.Add(b8, 0, wx.GROW|wx.ALL, space)
            bsizer.Add(b9, 0, wx.GROW|wx.ALL, space)
            bsizer.Add(b10, 0, wx.GROW|wx.ALL, space)
        bsizer.Add((5,1), 0)

        #bsizer.Add((32,10), space)

        sizer = wx.BoxSizer(wx.VERTICAL) #wx.FlexGridSizer(cols=1, hgap=space, vgap=space)
        sizer.Add(t3, proportion=1, flag=wx.EXPAND | wx.ALL,  border=5)  #proportion=1,
        sizer.Add(bsizer, 0, wx.EXPAND, 0)
        
        self.SetSizer(sizer)
        self.SetAutoLayout(True)
    
        self.Bind(wx.EVT_MOUSE_EVENTS, self.OnMouseEvent)

        self.isAlt=0;
        self.isShift=0;
        self.isCtrl=0;
        
        self.Fn_pressed=0;

        #if underlined==1:
        #    b3.SetBackgroundColour((255, 230, 200, 255))
        #else:
        #    b3.SetBackgroundColour((0, 0, 0, 0))

        #if bold==1:
        #    b4.SetBackgroundColour((255, 230, 200, 255))
        #else:
        #    b4.SetBackgroundColour((0, 0, 0, 0))

        #if italics==1:
        #    b5.SetBackgroundColour((255, 230, 200, 255))
        #else:
        #    b5.SetBackgroundColour((0, 0, 0, 0))

        if (hidden==1):
            #self.b2.SetBackgroundColour((255, 230, 200, 255))
            self.tc.SetForegroundColour((134,132,130, 255))
        else:
            #self.b2.SetBackgroundColour((0, 0, 0, 0))
            self.tc.SetForegroundColour((255, 255, 255, 255))

        style = self.tc.GetWindowStyle()
        if adjust==0:
            self.tc.SetWindowStyle(style & ~wx.TE_RIGHT & ~wx.TE_CENTER | wx.TE_LEFT)
        elif adjust==1:
            self.tc.SetWindowStyle(style & ~wx.TE_LEFT & ~wx.TE_CENTER | wx.TE_RIGHT)
        elif adjust==2:
            self.tc.SetWindowStyle(style & ~wx.TE_RIGHT & ~wx.TE_LEFT | wx.TE_CENTER)
        else:
            self.tc.SetWindowStyle(style & ~wx.TE_RIGHT & ~wx.TE_LEFT | wx.TE_CENTER)
            
        start, end = self.tc.GetSelection()
        insp=self.tc.GetInsertionPoint()
        
        self.tc.SetInsertionPoint(insp)
        self.tc.SetFocus()
        self.tc.SetSelection(start, end)

    def OnMouseEvent (self, evt):
        et = evt.GetEventType()

        if et == wx.wxEVT_LEFT_DOWN:
            self.OnLeftDown(evt)
        if et == wx.wxEVT_LEFT_UP:
            self.OnLeftUp(evt)
        if et == wx.wxEVT_MOTION:
            self.OnMouseMove(evt)
        if et == wx.wxEVT_RIGHT_DOWN:
            self.OnRightDown(evt)
        if et == wx.wxEVT_RIGHT_UP:
            self.OnRightUp(evt)

    def OnRightUp(self, evt):
        #self.parentFrame.Close()
        evt.Skip()

    def OnRightDown(self, evt):

        #if len(self.tc.GetValue()) == 0:
        if ((len(self.tc.GetValue()) == 0) or (single==1)):
            size = self.parentFrame.GetSize()
            width = size.GetWidth()
            height = size.GetHeight()

            position = self.parentFrame.GetPosition()
            x = position.x
            y = position.y
            geometry="%dx%d+%d+%d" % (width, height, x, y)
            edit_params = bold * 2 + italics * 4 + underlined * 8 + adjust * 16 + hidden * 64;

            if single==1:
                print("0\x1d0,%s>%d" %(geometry,edit_params))   #"800x80+2562+102", 0
            else:
                with open("/tmp/tinyfdt.txt", "w") as file:
                    file.write(self.tc.GetValue())
                    file.write("0\x1d0,%s>%d" %(geometry,edit_params))
                    print("0")
            #raise SystemExit
            self.parentFrame.Close()
        else:
            evt.Skip()

    def OnLeftDown(self, evt):
        self.CaptureMouse()
        self.leftDown = True
        pos = self.ClientToScreen(evt.GetPosition())
        origin = self.parentFrame.GetPosition()
        dx = pos.x - origin.x
        dy = pos.y - origin.y
        self.delta = wx.Point(dx, dy)

    def OnLeftUp(self, evt):
        self.ReleaseMouse()
        self.leftDown = False

    def OnMouseMove(self, evt):
        if evt.Dragging() and self.leftDown:
            pos = self.ClientToScreen(evt.GetPosition())
            fp = (pos.x - self.delta.x, pos.y - self.delta.y)
            #fp = (pos.x - self.delta.x, pos.y)
            self.parentFrame.Move(fp)

    def EvtText(self, event):
        #self.log.WriteText('EvtText: %s\n' % event.GetString())
        event.Skip()

    def EvtTextEnter(self, event):
        #self.log.WriteText('EvtTextEnter\n')
        if ((single==1) or (self.isCtrl==1)):
            self.GoEnter()
            event.Skip(False)
        else:
            event.Skip()

    def EvtChar(self, event):
        #self.log.WriteText('EvtChar: %d\n' % event.GetKeyCode())
        event.Skip()

    def OnAlt(self, evt):

        start, end = self.tc.GetSelection()

        insp=self.tc.GetInsertionPoint()
        # SET BACKGROUND COLOUR
        if (self.isAlt==0):
            #self.b1.SetBackgroundColour((255, 230, 200, 255))
            #self.b1.SetSize((40,40))
            self.b1.SetBitmap(self.bmp_Alt1)
            self.b1.Refresh();
            self.isAlt=1;
        else:
            #self.b1.SetBackgroundColour((0, 0, 0, 0))
            #self.b1.SetSize((32,32))
            self.b1.SetBitmap(self.bmp_Alt)
            self.b1.Refresh();
            self.isAlt=0;
        self.tc.SetInsertionPoint(insp)
        self.tc.SetFocus()

        self.tc.SetSelection(start, end)
        return

    def GoEsc(self):
        size = self.parentFrame.GetSize()
        width = size.GetWidth()
        height = size.GetHeight()

        position = self.parentFrame.GetPosition()
        x = position.x
        y = position.y
        geometry="%dx%d+%d+%d" % (width, height, x, y)
        edit_params = 1 + bold * 2 + italics * 4 + underlined * 8 + adjust * 16 + hidden * 64;

        if single==1:
            print("0\x1d%d,%s>%d" %(edit_params,geometry,global_cursor_pos))   #"800x80+2562+102", 0
        else:
            with open("/tmp/tinyfdt.txt", "w") as file:
                file.write(self.tc.GetValue())
                file.write("0\x1d%d,%s>%d" %(edit_params,geometry,global_cursor_pos))
                print("0")
        #raise SystemExit
        self.parentFrame.Close()

        return

    def GoExit(self):
        size = self.parentFrame.GetSize()
        width = size.GetWidth()
        height = size.GetHeight()

        position = self.parentFrame.GetPosition()
        x = position.x
        y = position.y
        geometry="%dx%d+%d+%d" % (width, height, x, y)
        edit_params = 1 + bold * 2 + italics * 4 + underlined * 8 + adjust * 16 + hidden * 64;

        print("0\x1d%d,%s>%d" %(edit_params,geometry,global_cursor_pos))   #"800x80+2562+102", 0

        #raise SystemExit
        self.parentFrame.Close()

        return

    def GoEnter(self):
        size = self.parentFrame.GetSize()
        width = size.GetWidth()
        height = size.GetHeight()

        position = self.parentFrame.GetPosition()
        x = position.x
        y = position.y
        geometry="%dx%d+%d+%d" % (width, height, x, y)
        edit_params = 1 + bold * 2 + italics * 4 + underlined * 8 + adjust * 16 + hidden * 64;
        wx.LogMessage("edit_params=%d" %edit_params)
        if single==1:
            print("1%s\x1d%d,%s>%d" %(self.tc.GetValue(),edit_params,geometry,global_cursor_pos))   #"800x80+2562+102", 0
        else:
            with open("/tmp/tinyfdt.txt", "w") as file:
                file.write(self.tc.GetValue())
                file.write("\x1d%d,%s>%d" %(edit_params,geometry,global_cursor_pos))
            print("1")
        #raise SystemExit
        self.parentFrame.Close()

    def GoSave(self):
        size = self.parentFrame.GetSize()
        width = size.GetWidth()
        height = size.GetHeight()

        position = self.parentFrame.GetPosition()
        x = position.x
        y = position.y
        geometry="%dx%d+%d+%d" % (width, height, x, y)
        edit_params = 1 + bold * 2 + italics * 4 + underlined * 8 + adjust * 16 + hidden * 64;
        wx.LogMessage("edit_params=%d" %edit_params)
        if self.edited==0:
            print("0")

            #raise SystemExit
            self.parentFrame.Close()
        else:
            with open("/tmp/tinyfdt.txt", "w") as file:
                file.write(self.tc.GetValue())
                file.write("\x1d%d,%s>%d" %(edit_params,geometry,global_cursor_pos))
            print("1")
            #raise SystemExit
            self.parentFrame.Close()

    def OnKeyDown(self, event):

        keycode = event.GetKeyCode()
        #wx.LogMessage("2) You pressed '%c'"%keycode)
        if keycode == wx.WXK_ESCAPE:
            #if len(self.tc.GetValue()) == 0:
            if ((len(self.tc.GetValue()) == 0) or (single==1)):

                if etype=='FILE':
                    self.GoEscape()
                else:
                    self.GoEsc()

        if keycode == wx.WXK_TAB:
            if etype!='FILE':
                if newtext==0:
                    self.GoEsc()
                else:
                    event.Skip(False)
                    return

        #print(keycode)
        
        if keycode == 0:
            if self.Fn_pressed==0:
                self.Fn_pressed=1
            else:
                self.Fn_pressed=0
            
            #print("+Fn_pressed=%d" %self.Fn_pressed)

        elif ((keycode == wx.WXK_ALT) and (self.isAlt == 0) and (self.Fn_pressed == 1)):
        #elif keycode == wx.WXK_RAW_CONTROL:
            #self.b1.SetBackgroundColour((255, 230, 200, 255))
            self.b1.SetBitmap(self.bmp_Alt1)
            self.b1.Refresh()
            self.isAlt=1
            #print("isAlt=%d" %self.isAlt)
            
        elif keycode == wx.WXK_SHIFT:
            self.isShift=1;
        elif keycode == wx.WXK_CONTROL:   #or wx.WXK_RAW_CONTROL for MacOS
            self.isCtrl=1;
        else:
            self.edited=1
            if (self.isAlt==1):
                match chr(keycode):
                    case '8':
                        keycode='°'
                        #wx.LogMessage("3) You changed to '%c'"%keycode)
                        self.tc.WriteText(keycode)
                        event.Skip(False)
                    case '4':
                        if (self.isShift==1):
                            keycode="€"
                        else:
                            keycode="⁴"
                        self.tc.WriteText(keycode)
                        event.Skip(False)
                    case '3':
                        keycode="³"
                        self.tc.WriteText(keycode)
                        event.Skip(False)
                    case '2':
                        keycode="²"
                        self.tc.WriteText(keycode)
                        event.Skip(False)
                    case '-':
                        keycode="±"
                        self.tc.WriteText(keycode)
                        event.Skip(False)
                    case '/':
                        keycode="÷"
                        self.tc.WriteText(keycode)
                        event.Skip(False)
                    case '.':
                        keycode="·";
                        self.tc.WriteText(keycode)
                        event.Skip(False)
                    case '1':
                        keycode="½"
                        self.tc.WriteText(keycode)
                        event.Skip(False)
                    case '5':
                        keycode="¼"
                        self.tc.WriteText(keycode)
                        event.Skip(False)
                    case '6':
                        keycode="¾"
                        self.tc.WriteText(keycode)
                        event.Skip(False)
                    case '0':
                        keycode="Ø"
                        self.tc.WriteText(keycode)
                        event.Skip(False)
                    case 'A':
                        if (self.isShift==1):
                            keycode="Α"
                        else:
                            keycode="α"
                        self.tc.WriteText(keycode)
                        event.Skip(False)
                    case 'B':
                        if (self.isShift==1):
                            keycode="Β"
                        else:
                            keycode="β"
                        self.tc.WriteText(keycode)
                        event.Skip(False)
                    case 'G':
                        if (self.isShift==1):
                            keycode="Γ"
                        else:
                            keycode="γ"
                        self.tc.WriteText(keycode)
                        event.Skip(False)
                    case 'D':
                        if (self.isShift==1):
                            keycode="Δ"
                        else:
                            keycode="δ"
                        self.tc.WriteText(keycode)
                        event.Skip(False)
                    case 'E':
                        if (self.isShift==1):
                            keycode="Ε"
                        else:
                            keycode="ε"
                        self.tc.WriteText(keycode)
                        event.Skip(False)
                    case 'Z':
                        if (self.isShift==1):
                            keycode="Ζ"
                        else:
                            keycode="ζ"
                        self.tc.WriteText(keycode)
                        event.Skip(False)
                    case 'Q':
                        if (self.isShift==1):
                            keycode="Η"
                        else:
                            keycode="η"
                        self.tc.WriteText(keycode)
                        event.Skip(False)
                    case 'H':
                        if (self.isShift==1):
                            keycode="Θ"
                        else:
                            keycode="θ"
                        self.tc.WriteText(keycode)
                        event.Skip(False)
                    case 'I':
                        if (self.isShift==1):
                            keycode="Ι"
                        else:
                            keycode="ι"
                        self.tc.WriteText(keycode)
                        event.Skip(False)
                    case 'K':
                        if (self.isShift==1):
                            keycode="Κ"
                        else:
                            keycode="κ"
                        self.tc.WriteText(keycode)
                        event.Skip(False)
                    case 'L':
                        if (self.isShift==1):
                            keycode="Λ"
                        else:
                            keycode="λ"
                        self.tc.WriteText(keycode)
                        event.Skip(False)
                    case 'M':
                        if (self.isShift==1):
                            keycode="Μ"
                        else:
                            keycode="μ"
                        self.tc.WriteText(keycode)
                        event.Skip(False)
                    case 'N':
                        if (self.isShift==1):
                            keycode="Ν"
                        else:
                            keycode="ν"
                        self.tc.WriteText(keycode)
                        event.Skip(False)
                    case 'X':
                        if (self.isShift==1):
                            keycode="Ξ"
                        else:
                            keycode="ξ"
                        self.tc.WriteText(keycode)
                        event.Skip(False)
                    case 'O':
                        if (self.isShift==1):
                            keycode="Ο"
                        else:
                            keycode="ο"
                        self.tc.WriteText(keycode)
                        event.Skip(False)
                    case 'P':
                        if (self.isShift==1):
                            keycode="Π"
                        else:
                            keycode="π"
                        self.tc.WriteText(keycode)
                        event.Skip(False)
                    case 'R':
                        if (self.isShift==1):
                            keycode="Ρ"
                        else:
                            keycode="ρ"
                        self.tc.WriteText(keycode)
                        event.Skip(False)
                    case 'S':
                        if (self.isShift==1):
                            keycode="Σ"
                        else:
                            keycode="σ"
                        self.tc.WriteText(keycode)
                        event.Skip(False)
                    case 'T':
                        if (self.isShift==1):
                            keycode="Τ"
                        else:
                            keycode="τ"
                        self.tc.WriteText(keycode)
                        event.Skip(False)
                    case 'Y':
                        if (self.isShift==1):
                            keycode="Υ"
                        else:
                            keycode="υ"
                        self.tc.WriteText(keycode)
                        event.Skip(False)
                    case 'F':
                        if (self.isShift==1):
                            keycode="Φ"
                        else:
                            keycode="φ"
                        self.tc.WriteText(keycode)
                        event.Skip(False)
                    case 'C':
                        if (self.isShift==1):
                            keycode="Χ"
                        else:
                            keycode="χ"
                        self.tc.WriteText(keycode)
                        event.Skip(False)
                    case 'U':
                        if (self.isShift==1):
                            keycode="Ψ"
                        else:
                            keycode="ψ"
                        self.tc.WriteText(keycode)
                        event.Skip(False)
                    case 'W':
                        if (self.isShift==1):
                            keycode="Ω"
                        else:
                            keycode="ω"
                        self.tc.WriteText(keycode)
                        event.Skip(False)
                    case 'J':
                        if (self.isShift==1):
                            keycode="Ϳ"
                        else:
                            keycode="ϳ"
                        self.tc.WriteText(keycode)
                        event.Skip(False)
                    case 'V':
                        if (self.isShift==1):
                            keycode="Ͷ"
                        else:
                            keycode="ͷ"
                        self.tc.WriteText(keycode)
                        event.Skip(False)
                    case '\\':
                        keycode="√"
                        self.tc.WriteText(keycode)
                        event.Skip(False)
                    case '|':
                        keycode="∛"
                        self.tc.WriteText(keycode)
                        event.Skip(False)
                    case _:
                        event.Skip()
            else:
                event.Skip()

    def OnKeyUp(self, event):

        keycode = event.GetKeyCode()
        
        if keycode == 0:
            self.Fn_pressed=0
            
            #print("-Fn_pressed=%d" %self.Fn_pressed)
            
        #wx.LogMessage("2) You released '%c'"%keycode)
        elif ((keycode == wx.WXK_ALT) and (self.isAlt == 1)): #and self.Fn_pressed == 1:
        #if keycode == wx.WXK_RAW_CONTROL:
            #self.b1.SetBackgroundColour((0, 0, 0, 0))
            self.b1.SetBitmap(self.bmp_Alt)
            self.b1.Refresh()
            self.isAlt=0
            #print("isAlt=%d" %self.isAlt)
             
        elif keycode == wx.WXK_SHIFT:
            self.isShift=0
        elif keycode == wx.WXK_CONTROL:   #or wx.WXK_RAW_CONTROL for MacOS
            self.isCtrl=0

        event.Skip()

    def OnChar(self, event):

        keycode = event.GetUnicodeKey()
        #wx.LogMessage("1) You pressed '%c'"%keycode)

        if keycode != wx.WXK_NONE:

            # It's a printable character
            #wx.LogMessage("You pressed '%d'"%keycode)

            #match keycode:
            #    case keycode:
            #        #wx.LogMessage("You pressed '%c'"%keycode)
            #        event.SetKeyCode(ord('°'))
            #        #event.SetKeyCode("°".encode('utf-8'))
            #        #event.SetKeyCode(unicode("°",('utf-8')))
            event.Skip()

        else:

            # It's a special key, deal with all the known ones:
            keycode = event.GetKeyCode()
            #if keycode in [wx.WXK_LEFT, wx.WXK_RIGHT]:
            #    wx.LogMessage("You pressed arrow key")

            #elif keycode == wx.WXK_F1:
            #    wx.LogMessage("You pressed F1")

            event.Skip()

    def OnHidden(self, evt):
        global hidden

        start, end = self.tc.GetSelection()
        insp=self.tc.GetInsertionPoint()

        if (hidden==0):
            #self.b2.SetBackgroundColour((255, 230, 200, 255))
            self.b2.SetBitmap(self.bmp_hidden1)
            self.b2.Refresh();
            self.tc.SetForegroundColour((134,132,130, 255))
            hidden=1
        else:
            #self.b2.SetBackgroundColour((0, 0, 0, 0))
            self.b2.SetBitmap(self.bmp_hidden)
            self.b2.Refresh();
            self.tc.SetForegroundColour((255, 255, 255, 255))
            hidden=0

        tc_=self.tc.GetValue()

        self.tc.Clear()
        self.tc.SetInsertionPoint(0)
        self.tc.WriteText(tc_)

        self.tc.SetInsertionPoint(insp)
        self.tc.SetFocus()
        self.tc.SetSelection(start, end)
        return

    def OnUnderlined(self, evt):
        #global italics
        #global bold
        global underlined
        #global hidden

        start, end = self.tc.GetSelection()
        insp=self.tc.GetInsertionPoint()
        if (underlined==0):
            #self.b3.SetBackgroundColour((255, 230, 200, 255))
            self.b3.SetBitmap(self.bmp_underlined1)
            self.b3.Refresh();
            underlined=1
        else:
            #self.b3.SetBackgroundColour((0, 0, 0, 0))
            self.b3.SetBitmap(self.bmp_underlined)
            self.b3.Refresh();
            underlined=0

        if (italics==0):
            styled=wx.FONTSTYLE_NORMAL
        else:
            styled=wx.FONTSTYLE_ITALIC
        if (bold==0):
            weighted=wx.FONTWEIGHT_SEMIBOLD
        else:
            weighted=wx.FONTWEIGHT_BOLD

        if (hidden==0):
            self.tc.SetForegroundColour((255, 255, 255, 255))
        else:
            self.tc.SetForegroundColour((134,132,130, 255))

        wx.LogMessage("underlined=%d" %underlined)

        f = wx.Font(pixelSize=(wx.Size(int(fontwidth), int(fontsize))), family=wx.FONTFAMILY_DEFAULT, style=styled, weight=weighted, underline=underlined, faceName=fontface, encoding=wx.FONTENCODING_UTF8)
        
        if (underlined==1):
            f.MakeUnderlined()
        self.tc.SetFont(f)
        
        #if (underlined==1):
        #    f.SetUnderlined(True)

        self.tc.SetInsertionPoint(insp)
        self.tc.SetFocus()
        self.tc.SetSelection(start, end)
        return

    def OnBold(self, evt):
        global italics
        global bold
        global underlined
        global hidden

        start, end = self.tc.GetSelection()
        insp=self.tc.GetInsertionPoint()
        if (bold==0):
            #self.b4.SetBackgroundColour((255, 230, 200, 255))
            self.b4.SetBitmap(self.bmp_bold1)
            self.b4.Refresh();
            bold=1
        else:
            #self.b4.SetBackgroundColour((0, 0, 0, 0))
            self.b4.SetBitmap(self.bmp_bold)
            self.b4.Refresh();
            bold=0

        if (italics==0):
            styled=wx.FONTSTYLE_NORMAL
        else:
            styled=wx.FONTSTYLE_ITALIC
        if (bold==0):
            weighted=wx.FONTWEIGHT_SEMIBOLD
        else:
            weighted=wx.FONTWEIGHT_BOLD

        if (hidden==0):
            self.tc.SetForegroundColour((255, 255, 255, 255))
        else:
            self.tc.SetForegroundColour((134,132,130, 255))

        f = wx.Font(pixelSize=(wx.Size(int(fontwidth), int(fontsize))), family=wx.FONTFAMILY_DEFAULT, style=styled, weight=weighted, underline=underlined, faceName=fontface, encoding=wx.FONTENCODING_UTF8)
        
        if (bold==1):
            f.MakeBold()
        self.tc.SetFont(f)

        self.tc.SetInsertionPoint(insp)
        self.tc.SetFocus()
        self.tc.SetSelection(start, end)
        return

    def OnItalics(self, evt):
        global italics
        global bold
        global underlined
        global hidden

        start, end = self.tc.GetSelection()
        insp=self.tc.GetInsertionPoint()
        if (italics==0):
            #self.b5.SetBackgroundColour((255, 230, 200, 255))
            self.b5.SetBitmap(self.bmp_italics1)
            self.b5.Refresh();
            italics=1
        else:
            #self.b5.SetBackgroundColour((0, 0, 0, 0))
            self.b5.SetBitmap(self.bmp_italics)
            self.b5.Refresh();
            italics=0

        if (italics==0):
            styled=wx.FONTSTYLE_NORMAL
        else:
            styled=wx.FONTSTYLE_ITALIC
        if (bold==0):
            weighted=wx.FONTWEIGHT_SEMIBOLD
        else:
            weighted=wx.FONTWEIGHT_BOLD

        if (hidden==0):
            self.tc.SetForegroundColour((255, 255, 255, 255))
        else:
            self.tc.SetForegroundColour((134,132,130, 255))

        f = wx.Font(pixelSize=(wx.Size(int(fontwidth), int(fontsize))), family=wx.FONTFAMILY_DEFAULT, style=styled, weight=weighted, underline=underlined, faceName=fontface, encoding=wx.FONTENCODING_UTF8)
        self.tc.SetFont(f)

        self.tc.SetInsertionPoint(insp)
        self.tc.SetFocus()
        self.tc.SetSelection(start, end)
        return

    def OnAlignLeft(self, evt):
        global adjust

        adjust=0

        start, end = self.tc.GetSelection()
        insp=self.tc.GetInsertionPoint()

        style = self.tc.GetWindowStyle()
        self.tc.SetWindowStyle(style & ~wx.TE_RIGHT & ~wx.TE_CENTER | wx.TE_LEFT)

        self.tc.SetInsertionPoint(insp)
        self.tc.SetFocus()
        self.tc.SetSelection(start, end)
        return

    def OnAlignCenter(self, evt):
        global adjust

        adjust=2

        start, end = self.tc.GetSelection()
        insp=self.tc.GetInsertionPoint()

        style = self.tc.GetWindowStyle()
        self.tc.SetWindowStyle(style & ~wx.TE_RIGHT & ~wx.TE_LEFT | wx.TE_CENTER)

        self.tc.SetInsertionPoint(insp)
        self.tc.SetFocus()
        self.tc.SetSelection(start, end)
        return

    def OnAlignMiddleCenter(self, evt):
        global adjust

        adjust=3

        start, end = self.tc.GetSelection()
        insp=self.tc.GetInsertionPoint()

        style = self.tc.GetWindowStyle()
        self.tc.SetWindowStyle(style & ~wx.TE_RIGHT & ~wx.TE_LEFT | wx.TE_CENTER)

        self.tc.SetInsertionPoint(insp)
        self.tc.SetFocus()
        self.tc.SetSelection(start, end)
        return

    def OnAlignRight(self, evt):
        global adjust

        adjust=1

        start, end = self.tc.GetSelection()
        insp=self.tc.GetInsertionPoint()

        style = self.tc.GetWindowStyle()
        self.tc.SetWindowStyle(style & ~wx.TE_LEFT & ~wx.TE_CENTER | wx.TE_RIGHT)

        self.tc.SetInsertionPoint(insp)
        self.tc.SetFocus()
        self.tc.SetSelection(start, end)
        return

    def OnEsc(self, evt):

        self.GoEsc()

    def OnExit(self, evt):

        self.GoExit()

    def OnEnter(self, evt):

        self.GoEnter();

    def OnSave(self, evt):

        self.GoSave();

    def OnTestReplace(self, evt):
        self.tc.Replace(5, 9, "IS A")
        #self.tc.Remove(5, 9)

    def OnTestWriteText(self, evt):
        self.tc.WriteText("TEXT")

    def OnTestGetSelection(self, evt):
        start, end = self.tc.GetSelection()
        text = self.tc.GetValue()
        if wx.Platform == "__WXMSW__":  # This is why GetStringSelection was added
            text = text.replace('\n', '\r\n')

        self.log.write("multi-line GetSelection(): (%d, %d)\n"
                       "\tGetStringSelection(): %s\n"
                       "\tSelectedText: %s\n" %
                       (start, end,
                        self.tc.GetStringSelection(),
                        repr(text[start:end])))

        start, end = self.tc1.GetSelection()
        text = self.tc1.GetValue()

        if wx.Platform == "__WXMSW__":  # This is why GetStringSelection was added
            text = text.replace('\n', '\r\n')

        self.log.write("single-line GetSelection(): (%d, %d)\n"
                       "\tGetStringSelection(): %s\n"
                       "\tSelectedText: %s\n" %
                       (start, end,
                        self.tc1.GetStringSelection(),
                        repr(text[start:end])))

    def OnT5LeftDown(self, evt):
        evt.Skip()
        wx.CallAfter(self.LogT5Position, evt)

    def LogT5Position(self, evt):
        text = self.t5.GetValue()
        ip = self.t5.GetInsertionPoint()
        lp = self.t5.GetLastPosition()
        try:
            self.log.write("LogT5Position:\n"
                           "\tGetInsertionPoint:\t%d\n"
                           "\ttext[insertionpoint]:\t%s\n"
                           "\tGetLastPosition:\t%d\n"
                           "\tlen(text):\t\t%d\n"
                           % (ip, text[ip], lp, len(text)))
        except Exception as exc:#last position eol or eof
            self.log.write("LogT5Position:\n"
                           "\tGetInsertionPoint:\t%d\n"
                           "\tGetLastPosition:\t%d\n"
                           "\tlen(text):\t\t%d\n"
                           % (ip, lp, len(text)))
                           
                           
    def init_edit(self):
        #start, end = self.tc.GetSelection()
        insp=self.tc.GetInsertionPoint()
        
        #self.tc.SetInsertionPoint(insp)
        self.tc.SetFocus()
        self.tc.SetInsertionPoint(insp)
        #self.tc.SetSelection(start, end)
        
        self.tc.Raise()
        self.tc.Refresh()

#---------------------------------------------------------------------------


overview = """\
A TextCtrl allows text to be displayed and (possibly) edited. It may be single
line or multi-line, support styles or not, be read-only or not, and even supports
text masking for such things as passwords.


"""

class AlfaEditApp(wx.App, wx.lib.mixins.inspection.InspectionMixin):
    global origin_x
    global origin_y

    def __init__(self, name, module, useShell):
        self.name = name
        self.demoModule = module
        self.useShell = useShell
        wx.App.__init__(self, redirect=False)

    def OnInit(self):
        global margin
        global hscrollbar

        wx.Log.SetActiveTarget(wx.LogStderr())

        self.SetAssertMode(assertMode)
        self.InitInspection()  # for the InspectionMixin base class

        if hscrollbar==1:
            wx.LogMessage("margin=%d"%margin)
            margin=margin+int(wx.SystemSettings.GetMetric(wx.SYS_HSCROLL_Y)/2)
            wx.LogMessage("margin=%d"%margin)

        if single==1:
            if platform=='darwin':
                f_style= wx.RESIZE_BORDER | wx.STAY_ON_TOP | wx.FRAME_NO_TASKBAR # | wx.DEFAULT_FRAME_STYLE | wx.NO_BORDER
            else:
                f_style=wx.RESIZE_BORDER | wx.STAY_ON_TOP | wx.FRAME_NO_TASKBAR | wx.NO_BORDER   # wx.DEFAULT_FRAME_STYLE | wx.NO_BORDER
            f_size=(width,64+int(fontsize)+margin)
        else:
            if platform=='darwin':
                f_style= wx.RESIZE_BORDER | wx.STAY_ON_TOP | wx.FRAME_NO_TASKBAR  # wx.DEFAULT_FRAME_STYLE | wx.NO_BORDER
            else:
                f_style=wx.RESIZE_BORDER | wx.STAY_ON_TOP | wx.FRAME_NO_TASKBAR | wx.NO_BORDER   # wx.DEFAULT_FRAME_STYLE | wx.NO_BORDER
            f_size=(width,height)

        frame = wx.Frame(None, -1, "Edit text(" + client + ")", size=f_size, style=f_style, name="Edit text(" + client + ")")

        if platform=='linux':
            frame.CreateStatusBar()  #hashing this is removing bottom right corner

        frame.SetLabel(self.name)

        icon = wx.Icon()
        icon.CopyFromBitmap(wx.Bitmap("Bitmaps/AlfaCAD96.png", wx.BITMAP_TYPE_ANY))

        frame.SetIcon(icon)

        if single==1:
            frame.SetMinSize( wx.Size(200, 64+int(fontsize)+margin))
            frame.SetMaxSize( wx.Size(3000, 64+int(fontsize)+margin))
            frame.SetSize(wx.Size(width, 64+int(fontsize)+margin))
        else:
            frame.SetMinSize( wx.Size(200, 64+int(fontsize)+margin))
            frame.SetMaxSize( wx.Size(3000, 2000))
            frame.SetSize(wx.Size(width, height))


        frame.SetPosition(wx.Point(origin_x, origin_y))

        frame.Show(True)
        frame.Bind(wx.EVT_CLOSE, self.OnCloseFrame)

        frame.Bind(wx.EVT_MOUSE_EVENTS, self.OnMouseEvent)

        win = AlfaEditPanel(frame, Log())

        if win:
            # so set the frame to a good size for showing stuff
            frame.SetSize(f_size)
            win.SetFocus()
            self.window = win
            frect = frame.GetRect()

        else:
            # It was probably a dialog or something that is already
            # gone, so we're done.
            frame.Destroy()
            return True

        self.SetTopWindow(frame)
        self.frame = frame
        #wx.Log.SetActiveTarget(wx.LogStderr())
        #wx.Log.SetTraceMask(wx.TraceMessages)

        if self.useShell:
            # Make a PyShell window, and position it below our test window
            from wx import py
            shell = py.shell.ShellFrame(None, locals=ns)
            frect.OffsetXY(0, frect.height)
            frect.height = height
            shell.SetRect(frect)
            shell.Show()

            # Hook the close event of the test window so that we close
            # the shell at the same time
            def CloseShell(evt):
                if shell:
                    shell.Close()
                evt.Skip()
            frame.Bind(wx.EVT_CLOSE, CloseShell)
            
        frame.Layout()
        frame.Refresh()
        
        
        win.Raise()
        win.init_edit()
        
        #wx.Frame.SetFocus(frame)
        wx.Frame.SetFocus(self.window)
        #wx.Frame.SetFocus(win.tc)
        #win.init_edit()
        
        frame.Raise()

        return True

    def OnExitApp(self, evt):
        self.frame.Close(True)

    def OnCloseFrame(self, evt):
        if hasattr(self, "window") and hasattr(self.window, "ShutdownDemo"):
            self.window.ShutdownDemo()
        evt.Skip()


    def OnMouseEvent (self, evt):
        et = evt.GetEventType()

        if et == wx.EVT_LEFT_DOWN:
            self.OnLeftDown()
        if et == wx.EVT_LEFT_UP:
            self.OnLeftUp()
        if et == wx.EVT_MOTION:
            self.OnMouseMove()
        if et == wx.EVT_RIGHT_UP:
            self.OnRightUp()

    def OnRightUp(self, evt):
        self.parentFrame.Close()

    def OnLeftDown(self, evt):
        self.CaptureMouse()
        self.leftDown = true
        pos = self.ClientToScreen(evt.GetPosition())
        origin = self.parentFrame.GetPosition()
        dx = pos.x - origin.x
        dy = pos.y - origin.y
        self.delta = wxPoint(dx, dy)

    def OnLeftUp(self, evt):
        self.ReleaseMouse()
        self.leftDown = false

    def OnMouseMove(self, evt):
        if evt.Dragging() and self.leftDown:
            pos = self.ClientToScreen(evt.GetPosition())
            fp = (pos.x - self.delta.x, pos.y - self.delta.y)
            self.parentFrame.Move(fp)

    def OnWidgetInspector(self, evt):
        wx.lib.inspection.InspectionTool().Show()
        
        
        
def go_foreground():
    NSApplication.sharedApplication()
    NSApp().activateIgnoringOtherApps_(True)


#----------------------------------------------------------------------------

def main(argv):

    global client
    global app
    global aTitle
    global aMessage
    global aDefaultInput
    global fontface
    global fontfile
    global fontsize
    global fontwidth
    global etype
    global params

    global bold
    global italics
    global underlined
    global adjust
    global hidden


    global single
    global geometry

    global width
    global height
    global origin_x
    global origin_y

    global TTF_path
    global OTF_path

    global lang

    global newtext

    useShell = False
    for x in range(len(sys.argv)):
        if sys.argv[x] in ['--shell', '-shell', '-s']:
            useShell = True
            del sys.argv[x]
            break

    if len(sys.argv) > 1:
        app, aTitle, aMessage, aDefaultInput, fontface, fontfile, fontsize, fontwidth, etype, params, single_str, geometry, TTF_path, OTF_path, lang_str = sys.argv[0:]
    else:
        raise SystemExit

    lang=languages.index(lang_str)

    #saving pid file
    with open(aTitle+".pid", "w") as file:
        file.write(str(pid)+"\n")

    single=int(single_str)
   
    geometry_split = geometry.replace("x"," ").replace("+"," ")
    #print(geometry_split,"\n")
    width, height, origin_x, origin_y = map(int, geometry_split.split())

    iparams=int(params)
    bold = bool(iparams & 2)
    italics = bool(iparams & 4)
    underlined = bool(iparams & 8)
    adjust1 = bool(iparams & 16)
    adjust2 = bool(iparams & 32)
    adjust = adjust1 + adjust2*2
    hidden = bool(iparams & 64)

    if len(aMessage)>0:
        newtext=0

    sTitle="%s — KDialog4alfa" %aTitle

    name=sTitle
    module=""
    useShell=0

    app = AlfaEditApp(name, module, useShell)
    #locale = wx.Locale(wx.LANGUAGE_DEFAULT)
    
    if platform == "darwin":
        try:
            go_foreground()
        except:
            pass

    app.MainLoop()

if __name__ == "__main__":
    main(sys.argv)


