# Install script for directory: /home/marek/libharu-master

# Set the install prefix
if(NOT DEFINED CMAKE_INSTALL_PREFIX)
  set(CMAKE_INSTALL_PREFIX "/usr/local")
endif()
string(REGEX REPLACE "/$" "" CMAKE_INSTALL_PREFIX "${CMAKE_INSTALL_PREFIX}")

# Set the install configuration name.
if(NOT DEFINED CMAKE_INSTALL_CONFIG_NAME)
  if(BUILD_TYPE)
    string(REGEX REPLACE "^[^A-Za-z0-9_]+" ""
           CMAKE_INSTALL_CONFIG_NAME "${BUILD_TYPE}")
  else()
    set(CMAKE_INSTALL_CONFIG_NAME "Release")
  endif()
  message(STATUS "Install configuration: \"${CMAKE_INSTALL_CONFIG_NAME}\"")
endif()

# Set the component getting installed.
if(NOT CMAKE_INSTALL_COMPONENT)
  if(COMPONENT)
    message(STATUS "Install component: \"${COMPONENT}\"")
    set(CMAKE_INSTALL_COMPONENT "${COMPONENT}")
  else()
    set(CMAKE_INSTALL_COMPONENT)
  endif()
endif()

# Install shared libraries without execute permission?
if(NOT DEFINED CMAKE_INSTALL_SO_NO_EXE)
  set(CMAKE_INSTALL_SO_NO_EXE "0")
endif()

# Is this installation the result of a crosscompile?
if(NOT DEFINED CMAKE_CROSSCOMPILING)
  set(CMAKE_CROSSCOMPILING "FALSE")
endif()

# Set path to fallback-tool for dependency-resolution.
if(NOT DEFINED CMAKE_OBJDUMP)
  set(CMAKE_OBJDUMP "/usr/bin/objdump")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "Unspecified" OR NOT CMAKE_INSTALL_COMPONENT)
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/include" TYPE FILE FILES
    "/home/marek/libharu-master/include/hpdf.h"
    "/home/marek/libharu-master/include/hpdf_types.h"
    "/home/marek/libharu-master/include/hpdf_consts.h"
    "/home/marek/libharu-master/include/hpdf_annotation.h"
    "/home/marek/libharu-master/include/hpdf_catalog.h"
    "/home/marek/libharu-master/include/hpdf_conf.h"
    "/home/marek/libharu-master/include/hpdf_destination.h"
    "/home/marek/libharu-master/include/hpdf_doc.h"
    "/home/marek/libharu-master/include/hpdf_encoder.h"
    "/home/marek/libharu-master/include/hpdf_encrypt.h"
    "/home/marek/libharu-master/include/hpdf_encryptdict.h"
    "/home/marek/libharu-master/include/hpdf_error.h"
    "/home/marek/libharu-master/include/hpdf_ext_gstate.h"
    "/home/marek/libharu-master/include/hpdf_font.h"
    "/home/marek/libharu-master/include/hpdf_fontdef.h"
    "/home/marek/libharu-master/include/hpdf_gstate.h"
    "/home/marek/libharu-master/include/hpdf_image.h"
    "/home/marek/libharu-master/include/hpdf_info.h"
    "/home/marek/libharu-master/include/hpdf_list.h"
    "/home/marek/libharu-master/include/hpdf_mmgr.h"
    "/home/marek/libharu-master/include/hpdf_namedict.h"
    "/home/marek/libharu-master/include/hpdf_objects.h"
    "/home/marek/libharu-master/include/hpdf_outline.h"
    "/home/marek/libharu-master/include/hpdf_pages.h"
    "/home/marek/libharu-master/include/hpdf_page_label.h"
    "/home/marek/libharu-master/include/hpdf_streams.h"
    "/home/marek/libharu-master/include/hpdf_u3d.h"
    "/home/marek/libharu-master/include/hpdf_utils.h"
    "/home/marek/libharu-master/include/hpdf_pdfa.h"
    "/home/marek/libharu-master/include/hpdf_3dmeasure.h"
    "/home/marek/libharu-master/include/hpdf_exdata.h"
    "/home/marek/libharu-master/include/hpdf_version.h"
    "/home/marek/libharu-master/cmake-build-release/include/hpdf_config.h"
    )
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "Unspecified" OR NOT CMAKE_INSTALL_COMPONENT)
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/share/libharu" TYPE FILE FILES
    "/home/marek/libharu-master/README.md"
    "/home/marek/libharu-master/CHANGES"
    "/home/marek/libharu-master/INSTALL"
    )
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "Unspecified" OR NOT CMAKE_INSTALL_COMPONENT)
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/share/libharu" TYPE DIRECTORY FILES "/home/marek/libharu-master/bindings")
endif()

if(NOT CMAKE_INSTALL_LOCAL_ONLY)
  # Include the install script for each subdirectory.
  include("/home/marek/libharu-master/cmake-build-release/src/cmake_install.cmake")

endif()

string(REPLACE ";" "\n" CMAKE_INSTALL_MANIFEST_CONTENT
       "${CMAKE_INSTALL_MANIFEST_FILES}")
if(CMAKE_INSTALL_LOCAL_ONLY)
  file(WRITE "/home/marek/libharu-master/cmake-build-release/install_local_manifest.txt"
     "${CMAKE_INSTALL_MANIFEST_CONTENT}")
endif()
if(CMAKE_INSTALL_COMPONENT)
  if(CMAKE_INSTALL_COMPONENT MATCHES "^[a-zA-Z0-9_.+-]+$")
    set(CMAKE_INSTALL_MANIFEST "install_manifest_${CMAKE_INSTALL_COMPONENT}.txt")
  else()
    string(MD5 CMAKE_INST_COMP_HASH "${CMAKE_INSTALL_COMPONENT}")
    set(CMAKE_INSTALL_MANIFEST "install_manifest_${CMAKE_INST_COMP_HASH}.txt")
    unset(CMAKE_INST_COMP_HASH)
  endif()
else()
  set(CMAKE_INSTALL_MANIFEST "install_manifest.txt")
endif()

if(NOT CMAKE_INSTALL_LOCAL_ONLY)
  file(WRITE "/home/marek/libharu-master/cmake-build-release/${CMAKE_INSTALL_MANIFEST}"
     "${CMAKE_INSTALL_MANIFEST_CONTENT}")
endif()
